/*   1:    */ package com.intellij.uiDesigner.core;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Insets;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import javax.swing.JComponent;
/*   9:    */ 
/*  10:    */ public final class GridLayoutManager
/*  11:    */   extends AbstractLayout
/*  12:    */ {
/*  13: 26 */   private int myMinCellSize = 20;
/*  14:    */   private final int[] myRowStretches;
/*  15:    */   private final int[] myColumnStretches;
/*  16:    */   private final int[] myYs;
/*  17:    */   private final int[] myHeights;
/*  18:    */   private final int[] myXs;
/*  19:    */   private final int[] myWidths;
/*  20:    */   private LayoutState myLayoutState;
/*  21:    */   DimensionInfo myHorizontalInfo;
/*  22:    */   DimensionInfo myVerticalInfo;
/*  23:    */   private boolean mySameSizeHorizontally;
/*  24:    */   private boolean mySameSizeVertically;
/*  25: 75 */   public static Object DESIGN_TIME_INSETS = new Object();
/*  26:    */   private static final int SKIP_ROW = 1;
/*  27:    */   private static final int SKIP_COL = 2;
/*  28:    */   
/*  29:    */   public GridLayoutManager(int rowCount, int columnCount)
/*  30:    */   {
/*  31: 81 */     if (columnCount < 1) {
/*  32: 82 */       throw new IllegalArgumentException("wrong columnCount: " + columnCount);
/*  33:    */     }
/*  34: 84 */     if (rowCount < 1) {
/*  35: 85 */       throw new IllegalArgumentException("wrong rowCount: " + rowCount);
/*  36:    */     }
/*  37: 88 */     this.myRowStretches = new int[rowCount];
/*  38: 89 */     for (int i = 0; i < rowCount; i++) {
/*  39: 90 */       this.myRowStretches[i] = 1;
/*  40:    */     }
/*  41: 92 */     this.myColumnStretches = new int[columnCount];
/*  42: 93 */     for (int i = 0; i < columnCount; i++) {
/*  43: 94 */       this.myColumnStretches[i] = 1;
/*  44:    */     }
/*  45: 97 */     this.myXs = new int[columnCount];
/*  46: 98 */     this.myWidths = new int[columnCount];
/*  47:    */     
/*  48:100 */     this.myYs = new int[rowCount];
/*  49:101 */     this.myHeights = new int[rowCount];
/*  50:    */   }
/*  51:    */   
/*  52:    */   public GridLayoutManager(int rowCount, int columnCount, Insets margin, int hGap, int vGap)
/*  53:    */   {
/*  54:108 */     this(rowCount, columnCount);
/*  55:109 */     setMargin(margin);
/*  56:110 */     setHGap(hGap);
/*  57:111 */     setVGap(vGap);
/*  58:112 */     this.myMinCellSize = 0;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public GridLayoutManager(int rowCount, int columnCount, Insets margin, int hGap, int vGap, boolean sameSizeHorizontally, boolean sameSizeVertically)
/*  62:    */   {
/*  63:127 */     this(rowCount, columnCount, margin, hGap, vGap);
/*  64:128 */     this.mySameSizeHorizontally = sameSizeHorizontally;
/*  65:129 */     this.mySameSizeVertically = sameSizeVertically;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void addLayoutComponent(Component comp, Object constraints)
/*  69:    */   {
/*  70:133 */     GridConstraints c = (GridConstraints)constraints;
/*  71:134 */     int row = c.getRow();
/*  72:135 */     int rowSpan = c.getRowSpan();
/*  73:136 */     int rowCount = getRowCount();
/*  74:137 */     if ((row < 0) || (row >= rowCount)) {
/*  75:138 */       throw new IllegalArgumentException("wrong row: " + row);
/*  76:    */     }
/*  77:140 */     if (row + rowSpan - 1 >= rowCount) {
/*  78:141 */       throw new IllegalArgumentException("wrong row span: " + rowSpan + "; row=" + row + " rowCount=" + rowCount);
/*  79:    */     }
/*  80:143 */     int column = c.getColumn();
/*  81:144 */     int colSpan = c.getColSpan();
/*  82:145 */     int columnCount = getColumnCount();
/*  83:146 */     if ((column < 0) || (column >= columnCount)) {
/*  84:147 */       throw new IllegalArgumentException("wrong column: " + column);
/*  85:    */     }
/*  86:149 */     if (column + colSpan - 1 >= columnCount) {
/*  87:150 */       throw new IllegalArgumentException("wrong col span: " + colSpan + "; column=" + column + " columnCount=" + columnCount);
/*  88:    */     }
/*  89:153 */     super.addLayoutComponent(comp, constraints);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public int getRowCount()
/*  93:    */   {
/*  94:160 */     return this.myRowStretches.length;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public int getColumnCount()
/*  98:    */   {
/*  99:167 */     return this.myColumnStretches.length;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public int getRowStretch(int rowIndex)
/* 103:    */   {
/* 104:175 */     return this.myRowStretches[rowIndex];
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setRowStretch(int rowIndex, int stretch)
/* 108:    */   {
/* 109:183 */     if (stretch < 1) {
/* 110:184 */       throw new IllegalArgumentException("wrong stretch: " + stretch);
/* 111:    */     }
/* 112:186 */     this.myRowStretches[rowIndex] = stretch;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public int getColumnStretch(int columnIndex)
/* 116:    */   {
/* 117:194 */     return this.myColumnStretches[columnIndex];
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void setColumnStretch(int columnIndex, int stretch)
/* 121:    */   {
/* 122:202 */     if (stretch < 1) {
/* 123:203 */       throw new IllegalArgumentException("wrong stretch: " + stretch);
/* 124:    */     }
/* 125:205 */     this.myColumnStretches[columnIndex] = stretch;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public Dimension maximumLayoutSize(Container target)
/* 129:    */   {
/* 130:209 */     return new Dimension(2147483647, 2147483647);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public Dimension minimumLayoutSize(Container container)
/* 134:    */   {
/* 135:213 */     validateInfos(container);
/* 136:    */     
/* 137:    */ 
/* 138:216 */     DimensionInfo horizontalInfo = this.myHorizontalInfo;
/* 139:217 */     DimensionInfo verticalInfo = this.myVerticalInfo;
/* 140:    */     
/* 141:219 */     Dimension result = getTotalGap(container, horizontalInfo, verticalInfo);
/* 142:    */     
/* 143:221 */     int[] widths = getMinSizes(horizontalInfo);
/* 144:222 */     if (this.mySameSizeHorizontally) {
/* 145:223 */       makeSameSizes(widths);
/* 146:    */     }
/* 147:225 */     result.width += sum(widths);
/* 148:    */     
/* 149:227 */     int[] heights = getMinSizes(verticalInfo);
/* 150:228 */     if (this.mySameSizeVertically) {
/* 151:229 */       makeSameSizes(heights);
/* 152:    */     }
/* 153:231 */     result.height += sum(heights);
/* 154:    */     
/* 155:233 */     return result;
/* 156:    */   }
/* 157:    */   
/* 158:    */   private static void makeSameSizes(int[] widths)
/* 159:    */   {
/* 160:237 */     int max = widths[0];
/* 161:238 */     for (int i = 0; i < widths.length; i++)
/* 162:    */     {
/* 163:239 */       int width = widths[i];
/* 164:240 */       max = Math.max(width, max);
/* 165:    */     }
/* 166:243 */     for (int i = 0; i < widths.length; i++) {
/* 167:244 */       widths[i] = max;
/* 168:    */     }
/* 169:    */   }
/* 170:    */   
/* 171:    */   private static int[] getSameSizes(DimensionInfo info, int totalWidth)
/* 172:    */   {
/* 173:249 */     int[] widths = new int[info.getCellCount()];
/* 174:    */     
/* 175:251 */     int average = totalWidth / widths.length;
/* 176:252 */     int rest = totalWidth % widths.length;
/* 177:254 */     for (int i = 0; i < widths.length; i++)
/* 178:    */     {
/* 179:255 */       widths[i] = average;
/* 180:256 */       if (rest > 0)
/* 181:    */       {
/* 182:257 */         widths[i] += 1;
/* 183:258 */         rest--;
/* 184:    */       }
/* 185:    */     }
/* 186:262 */     return widths;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public Dimension preferredLayoutSize(Container container)
/* 190:    */   {
/* 191:266 */     validateInfos(container);
/* 192:    */     
/* 193:    */ 
/* 194:269 */     DimensionInfo horizontalInfo = this.myHorizontalInfo;
/* 195:270 */     DimensionInfo verticalInfo = this.myVerticalInfo;
/* 196:    */     
/* 197:272 */     Dimension result = getTotalGap(container, horizontalInfo, verticalInfo);
/* 198:    */     
/* 199:274 */     int[] widths = getPrefSizes(horizontalInfo);
/* 200:275 */     if (this.mySameSizeHorizontally) {
/* 201:276 */       makeSameSizes(widths);
/* 202:    */     }
/* 203:278 */     result.width += sum(widths);
/* 204:    */     
/* 205:280 */     int[] heights = getPrefSizes(verticalInfo);
/* 206:281 */     if (this.mySameSizeVertically) {
/* 207:282 */       makeSameSizes(heights);
/* 208:    */     }
/* 209:284 */     result.height += sum(heights);
/* 210:    */     
/* 211:286 */     return result;
/* 212:    */   }
/* 213:    */   
/* 214:    */   private static int sum(int[] ints)
/* 215:    */   {
/* 216:290 */     int result = 0;
/* 217:291 */     for (int i = ints.length - 1; i >= 0; i--) {
/* 218:292 */       result += ints[i];
/* 219:    */     }
/* 220:294 */     return result;
/* 221:    */   }
/* 222:    */   
/* 223:    */   private Dimension getTotalGap(Container container, DimensionInfo hInfo, DimensionInfo vInfo)
/* 224:    */   {
/* 225:298 */     Insets insets = getInsets(container);
/* 226:299 */     return new Dimension(insets.left + insets.right + 
/* 227:300 */       countGap(hInfo, 0, hInfo.getCellCount()) + this.myMargin.left + this.myMargin.right, insets.top + insets.bottom + 
/* 228:301 */       countGap(vInfo, 0, vInfo.getCellCount()) + this.myMargin.top + this.myMargin.bottom);
/* 229:    */   }
/* 230:    */   
/* 231:    */   private static int getDesignTimeInsets(Container container)
/* 232:    */   {
/* 233:305 */     while (container != null)
/* 234:    */     {
/* 235:306 */       if ((container instanceof JComponent))
/* 236:    */       {
/* 237:307 */         Integer designTimeInsets = (Integer)((JComponent)container).getClientProperty(DESIGN_TIME_INSETS);
/* 238:308 */         if (designTimeInsets != null) {
/* 239:309 */           return designTimeInsets.intValue();
/* 240:    */         }
/* 241:    */       }
/* 242:312 */       container = container.getParent();
/* 243:    */     }
/* 244:314 */     return 0;
/* 245:    */   }
/* 246:    */   
/* 247:    */   private static Insets getInsets(Container container)
/* 248:    */   {
/* 249:318 */     Insets insets = container.getInsets();
/* 250:319 */     int insetsValue = getDesignTimeInsets(container);
/* 251:320 */     if (insetsValue != 0) {
/* 252:321 */       return new Insets(insets.top + insetsValue, insets.left + insetsValue, insets.bottom + insetsValue, insets.right + insetsValue);
/* 253:    */     }
/* 254:324 */     return insets;
/* 255:    */   }
/* 256:    */   
/* 257:    */   private static int countGap(DimensionInfo info, int startCell, int cellCount)
/* 258:    */   {
/* 259:328 */     int counter = 0;
/* 260:329 */     for (int cellIndex = startCell + cellCount - 2; cellIndex >= startCell; cellIndex--) {
/* 261:332 */       if (shouldAddGapAfterCell(info, cellIndex)) {
/* 262:333 */         counter++;
/* 263:    */       }
/* 264:    */     }
/* 265:336 */     return counter * info.getGap();
/* 266:    */   }
/* 267:    */   
/* 268:    */   private static boolean shouldAddGapAfterCell(DimensionInfo info, int cellIndex)
/* 269:    */   {
/* 270:340 */     if ((cellIndex < 0) || (cellIndex >= info.getCellCount())) {
/* 271:341 */       throw new IllegalArgumentException("wrong cellIndex: " + cellIndex + "; cellCount=" + info.getCellCount());
/* 272:    */     }
/* 273:344 */     boolean endsInThis = false;
/* 274:345 */     boolean startsInNext = false;
/* 275:    */     
/* 276:347 */     int indexOfNextNotEmpty = -1;
/* 277:348 */     for (int i = cellIndex + 1; i < info.getCellCount(); i++) {
/* 278:349 */       if (!isCellEmpty(info, i))
/* 279:    */       {
/* 280:350 */         indexOfNextNotEmpty = i;
/* 281:351 */         break;
/* 282:    */       }
/* 283:    */     }
/* 284:355 */     for (int i = 0; i < info.getComponentCount(); i++)
/* 285:    */     {
/* 286:356 */       Component component = info.getComponent(i);
/* 287:357 */       if (!(component instanceof Spacer))
/* 288:    */       {
/* 289:361 */         if ((info.componentBelongsCell(i, cellIndex)) && 
/* 290:362 */           (DimensionInfo.findAlignedChild(component, info.getConstraints(i)) != null)) {
/* 291:363 */           return true;
/* 292:    */         }
/* 293:366 */         if (info.getCell(i) == indexOfNextNotEmpty) {
/* 294:367 */           startsInNext = true;
/* 295:    */         }
/* 296:370 */         if (info.getCell(i) + info.getSpan(i) - 1 == cellIndex) {
/* 297:371 */           endsInThis = true;
/* 298:    */         }
/* 299:    */       }
/* 300:    */     }
/* 301:375 */     return (startsInNext) && (endsInThis);
/* 302:    */   }
/* 303:    */   
/* 304:    */   private static boolean isCellEmpty(DimensionInfo info, int cellIndex)
/* 305:    */   {
/* 306:379 */     if ((cellIndex < 0) || (cellIndex >= info.getCellCount())) {
/* 307:380 */       throw new IllegalArgumentException("wrong cellIndex: " + cellIndex + "; cellCount=" + info.getCellCount());
/* 308:    */     }
/* 309:382 */     for (int i = 0; i < info.getComponentCount(); i++)
/* 310:    */     {
/* 311:383 */       Component component = info.getComponent(i);
/* 312:384 */       if ((info.getCell(i) == cellIndex) && (!(component instanceof Spacer))) {
/* 313:385 */         return false;
/* 314:    */       }
/* 315:    */     }
/* 316:388 */     return true;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public void layoutContainer(Container container)
/* 320:    */   {
/* 321:392 */     validateInfos(container);
/* 322:    */     
/* 323:    */ 
/* 324:395 */     LayoutState layoutState = this.myLayoutState;
/* 325:396 */     DimensionInfo horizontalInfo = this.myHorizontalInfo;
/* 326:397 */     DimensionInfo verticalInfo = this.myVerticalInfo;
/* 327:    */     
/* 328:399 */     Insets insets = getInsets(container);
/* 329:    */     
/* 330:401 */     int skipLayout = checkSetSizesFromParent(container, insets);
/* 331:    */     
/* 332:403 */     Dimension gap = getTotalGap(container, horizontalInfo, verticalInfo);
/* 333:    */     
/* 334:405 */     Dimension size = container.getSize();
/* 335:406 */     size.width -= gap.width;
/* 336:407 */     size.height -= gap.height;
/* 337:    */     
/* 338:409 */     Dimension prefSize = preferredLayoutSize(container);
/* 339:410 */     prefSize.width -= gap.width;
/* 340:411 */     prefSize.height -= gap.height;
/* 341:    */     
/* 342:413 */     Dimension minSize = minimumLayoutSize(container);
/* 343:414 */     minSize.width -= gap.width;
/* 344:415 */     minSize.height -= gap.height;
/* 345:418 */     if ((skipLayout & 0x1) == 0)
/* 346:    */     {
/* 347:    */       int[] heights;
/* 348:    */       int[] heights;
/* 349:420 */       if (this.mySameSizeVertically)
/* 350:    */       {
/* 351:421 */         heights = getSameSizes(verticalInfo, Math.max(size.height, minSize.height));
/* 352:    */       }
/* 353:424 */       else if (size.height < prefSize.height)
/* 354:    */       {
/* 355:425 */         int[] heights = getMinSizes(verticalInfo);
/* 356:426 */         new_doIt(heights, 0, verticalInfo.getCellCount(), size.height, verticalInfo, true);
/* 357:    */       }
/* 358:    */       else
/* 359:    */       {
/* 360:429 */         heights = getPrefSizes(verticalInfo);
/* 361:430 */         new_doIt(heights, 0, verticalInfo.getCellCount(), size.height, verticalInfo, false);
/* 362:    */       }
/* 363:435 */       int y = insets.top + this.myMargin.top;
/* 364:436 */       for (int i = 0; i < heights.length; i++)
/* 365:    */       {
/* 366:437 */         this.myYs[i] = y;
/* 367:438 */         this.myHeights[i] = heights[i];
/* 368:439 */         y += heights[i];
/* 369:440 */         if (shouldAddGapAfterCell(verticalInfo, i)) {
/* 370:441 */           y += verticalInfo.getGap();
/* 371:    */         }
/* 372:    */       }
/* 373:    */     }
/* 374:446 */     if ((skipLayout & 0x2) == 0)
/* 375:    */     {
/* 376:    */       int[] widths;
/* 377:    */       int[] widths;
/* 378:449 */       if (this.mySameSizeHorizontally)
/* 379:    */       {
/* 380:450 */         widths = getSameSizes(horizontalInfo, Math.max(size.width, minSize.width));
/* 381:    */       }
/* 382:453 */       else if (size.width < prefSize.width)
/* 383:    */       {
/* 384:454 */         int[] widths = getMinSizes(horizontalInfo);
/* 385:455 */         new_doIt(widths, 0, horizontalInfo.getCellCount(), size.width, horizontalInfo, true);
/* 386:    */       }
/* 387:    */       else
/* 388:    */       {
/* 389:458 */         widths = getPrefSizes(horizontalInfo);
/* 390:459 */         new_doIt(widths, 0, horizontalInfo.getCellCount(), size.width, horizontalInfo, false);
/* 391:    */       }
/* 392:464 */       int x = insets.left + this.myMargin.left;
/* 393:465 */       for (int i = 0; i < widths.length; i++)
/* 394:    */       {
/* 395:466 */         this.myXs[i] = x;
/* 396:467 */         this.myWidths[i] = widths[i];
/* 397:468 */         x += widths[i];
/* 398:469 */         if (shouldAddGapAfterCell(horizontalInfo, i)) {
/* 399:470 */           x += horizontalInfo.getGap();
/* 400:    */         }
/* 401:    */       }
/* 402:    */     }
/* 403:476 */     for (int i = 0; i < layoutState.getComponentCount(); i++)
/* 404:    */     {
/* 405:477 */       GridConstraints c = layoutState.getConstraints(i);
/* 406:478 */       Component component = layoutState.getComponent(i);
/* 407:    */       
/* 408:480 */       int column = horizontalInfo.getCell(i);
/* 409:481 */       int colSpan = horizontalInfo.getSpan(i);
/* 410:482 */       int row = verticalInfo.getCell(i);
/* 411:483 */       int rowSpan = verticalInfo.getSpan(i);
/* 412:    */       
/* 413:485 */       int cellWidth = this.myXs[(column + colSpan - 1)] + this.myWidths[(column + colSpan - 1)] - this.myXs[column];
/* 414:486 */       int cellHeight = this.myYs[(row + rowSpan - 1)] + this.myHeights[(row + rowSpan - 1)] - this.myYs[row];
/* 415:    */       
/* 416:488 */       Dimension componentSize = new Dimension(cellWidth, cellHeight);
/* 417:490 */       if ((c.getFill() & 0x1) == 0) {
/* 418:491 */         componentSize.width = Math.min(componentSize.width, horizontalInfo.getPreferredWidth(i));
/* 419:    */       }
/* 420:494 */       if ((c.getFill() & 0x2) == 0) {
/* 421:495 */         componentSize.height = Math.min(componentSize.height, verticalInfo.getPreferredWidth(i));
/* 422:    */       }
/* 423:498 */       Util.adjustSize(component, c, componentSize);
/* 424:    */       
/* 425:500 */       int dx = 0;
/* 426:501 */       int dy = 0;
/* 427:503 */       if ((c.getAnchor() & 0x4) != 0) {
/* 428:504 */         dx = cellWidth - componentSize.width;
/* 429:506 */       } else if ((c.getAnchor() & 0x8) == 0) {
/* 430:507 */         dx = (cellWidth - componentSize.width) / 2;
/* 431:    */       }
/* 432:510 */       if ((c.getAnchor() & 0x2) != 0) {
/* 433:511 */         dy = cellHeight - componentSize.height;
/* 434:513 */       } else if ((c.getAnchor() & 0x1) == 0) {
/* 435:514 */         dy = (cellHeight - componentSize.height) / 2;
/* 436:    */       }
/* 437:517 */       int indent = 10 * c.getIndent();
/* 438:518 */       componentSize.width -= indent;
/* 439:519 */       dx += indent;
/* 440:    */       
/* 441:521 */       component.setBounds(this.myXs[column] + dx, this.myYs[row] + dy, componentSize.width, componentSize.height);
/* 442:    */     }
/* 443:    */   }
/* 444:    */   
/* 445:    */   private int checkSetSizesFromParent(Container container, Insets insets)
/* 446:    */   {
/* 447:526 */     int skipLayout = 0;
/* 448:    */     
/* 449:528 */     GridLayoutManager parentGridLayout = null;
/* 450:529 */     GridConstraints parentGridConstraints = null;
/* 451:    */     
/* 452:    */ 
/* 453:532 */     Container parent = container.getParent();
/* 454:533 */     if (parent != null) {
/* 455:534 */       if ((parent.getLayout() instanceof GridLayoutManager))
/* 456:    */       {
/* 457:535 */         parentGridLayout = (GridLayoutManager)parent.getLayout();
/* 458:536 */         parentGridConstraints = parentGridLayout.getConstraintsForComponent(container);
/* 459:    */       }
/* 460:    */       else
/* 461:    */       {
/* 462:539 */         Container parent2 = parent.getParent();
/* 463:540 */         if ((parent2 != null) && ((parent2.getLayout() instanceof GridLayoutManager)))
/* 464:    */         {
/* 465:541 */           parentGridLayout = (GridLayoutManager)parent2.getLayout();
/* 466:542 */           parentGridConstraints = parentGridLayout.getConstraintsForComponent(parent);
/* 467:    */         }
/* 468:    */       }
/* 469:    */     }
/* 470:547 */     if ((parentGridLayout != null) && (parentGridConstraints.isUseParentLayout()))
/* 471:    */     {
/* 472:548 */       if (this.myRowStretches.length == parentGridConstraints.getRowSpan())
/* 473:    */       {
/* 474:549 */         int row = parentGridConstraints.getRow();
/* 475:550 */         this.myYs[0] = (insets.top + this.myMargin.top);
/* 476:551 */         this.myHeights[0] = (parentGridLayout.myHeights[row] - this.myYs[0]);
/* 477:552 */         for (int i = 1; i < this.myRowStretches.length; i++)
/* 478:    */         {
/* 479:553 */           this.myYs[i] = (parentGridLayout.myYs[(i + row)] - parentGridLayout.myYs[row]);
/* 480:554 */           this.myHeights[i] = parentGridLayout.myHeights[(i + row)];
/* 481:    */         }
/* 482:556 */         this.myHeights[(this.myRowStretches.length - 1)] -= insets.bottom + this.myMargin.bottom;
/* 483:557 */         skipLayout |= 0x1;
/* 484:    */       }
/* 485:559 */       if (this.myColumnStretches.length == parentGridConstraints.getColSpan())
/* 486:    */       {
/* 487:560 */         int col = parentGridConstraints.getColumn();
/* 488:561 */         this.myXs[0] = (insets.left + this.myMargin.left);
/* 489:562 */         this.myWidths[0] = (parentGridLayout.myWidths[col] - this.myXs[0]);
/* 490:563 */         for (int i = 1; i < this.myColumnStretches.length; i++)
/* 491:    */         {
/* 492:564 */           this.myXs[i] = (parentGridLayout.myXs[(i + col)] - parentGridLayout.myXs[col]);
/* 493:565 */           this.myWidths[i] = parentGridLayout.myWidths[(i + col)];
/* 494:    */         }
/* 495:567 */         this.myWidths[(this.myColumnStretches.length - 1)] -= insets.right + this.myMargin.right;
/* 496:568 */         skipLayout |= 0x2;
/* 497:    */       }
/* 498:    */     }
/* 499:571 */     return skipLayout;
/* 500:    */   }
/* 501:    */   
/* 502:    */   public void invalidateLayout(Container container)
/* 503:    */   {
/* 504:575 */     this.myLayoutState = null;
/* 505:576 */     this.myHorizontalInfo = null;
/* 506:577 */     this.myVerticalInfo = null;
/* 507:    */   }
/* 508:    */   
/* 509:    */   void validateInfos(Container container)
/* 510:    */   {
/* 511:581 */     if (this.myLayoutState == null)
/* 512:    */     {
/* 513:583 */       this.myLayoutState = new LayoutState(this, getDesignTimeInsets(container) == 0);
/* 514:584 */       this.myHorizontalInfo = new HorizontalInfo(this.myLayoutState, getHGapImpl(container));
/* 515:585 */       this.myVerticalInfo = new VerticalInfo(this.myLayoutState, getVGapImpl(container));
/* 516:    */     }
/* 517:    */   }
/* 518:    */   
/* 519:    */   public int[] getXs()
/* 520:    */   {
/* 521:593 */     return this.myXs;
/* 522:    */   }
/* 523:    */   
/* 524:    */   public int[] getWidths()
/* 525:    */   {
/* 526:600 */     return this.myWidths;
/* 527:    */   }
/* 528:    */   
/* 529:    */   public int[] getYs()
/* 530:    */   {
/* 531:607 */     return this.myYs;
/* 532:    */   }
/* 533:    */   
/* 534:    */   public int[] getHeights()
/* 535:    */   {
/* 536:614 */     return this.myHeights;
/* 537:    */   }
/* 538:    */   
/* 539:    */   public int[] getCoords(boolean isRow)
/* 540:    */   {
/* 541:618 */     return isRow ? this.myYs : this.myXs;
/* 542:    */   }
/* 543:    */   
/* 544:    */   public int[] getSizes(boolean isRow)
/* 545:    */   {
/* 546:622 */     return isRow ? this.myHeights : this.myWidths;
/* 547:    */   }
/* 548:    */   
/* 549:    */   private int[] getMinSizes(DimensionInfo info)
/* 550:    */   {
/* 551:626 */     return getMinOrPrefSizes(info, true);
/* 552:    */   }
/* 553:    */   
/* 554:    */   private int[] getPrefSizes(DimensionInfo info)
/* 555:    */   {
/* 556:630 */     return getMinOrPrefSizes(info, false);
/* 557:    */   }
/* 558:    */   
/* 559:    */   private int[] getMinOrPrefSizes(DimensionInfo info, boolean min)
/* 560:    */   {
/* 561:634 */     int[] widths = new int[info.getCellCount()];
/* 562:635 */     for (int i = 0; i < widths.length; i++) {
/* 563:636 */       widths[i] = this.myMinCellSize;
/* 564:    */     }
/* 565:640 */     for (int i = info.getComponentCount() - 1; i >= 0; i--) {
/* 566:641 */       if (info.getSpan(i) == 1)
/* 567:    */       {
/* 568:645 */         int size = min ? getMin2(info, i) : Math.max(info.getMinimumWidth(i), info.getPreferredWidth(i));
/* 569:646 */         int cell = info.getCell(i);
/* 570:647 */         int gap = countGap(info, cell, info.getSpan(i));
/* 571:648 */         size = Math.max(size - gap, 0);
/* 572:    */         
/* 573:650 */         widths[cell] = Math.max(widths[cell], size);
/* 574:    */       }
/* 575:    */     }
/* 576:654 */     updateSizesFromChildren(info, min, widths);
/* 577:    */     
/* 578:    */ 
/* 579:    */ 
/* 580:658 */     boolean[] toProcess = new boolean[info.getCellCount()];
/* 581:660 */     for (int i = info.getComponentCount() - 1; i >= 0; i--)
/* 582:    */     {
/* 583:661 */       int size = min ? getMin2(info, i) : Math.max(info.getMinimumWidth(i), info.getPreferredWidth(i));
/* 584:    */       
/* 585:663 */       int span = info.getSpan(i);
/* 586:664 */       int cell = info.getCell(i);
/* 587:    */       
/* 588:666 */       int gap = countGap(info, cell, span);
/* 589:667 */       size = Math.max(size - gap, 0);
/* 590:    */       
/* 591:669 */       Arrays.fill(toProcess, false);
/* 592:    */       
/* 593:671 */       int curSize = 0;
/* 594:672 */       for (int j = 0; j < span; j++)
/* 595:    */       {
/* 596:673 */         curSize += widths[(j + cell)];
/* 597:674 */         toProcess[(j + cell)] = true;
/* 598:    */       }
/* 599:677 */       if (curSize < size)
/* 600:    */       {
/* 601:681 */         boolean[] higherPriorityCells = new boolean[toProcess.length];
/* 602:682 */         getCellsWithHigherPriorities(info, toProcess, higherPriorityCells, false, widths);
/* 603:    */         
/* 604:684 */         distribute(higherPriorityCells, info, size - curSize, widths);
/* 605:    */       }
/* 606:    */     }
/* 607:687 */     return widths;
/* 608:    */   }
/* 609:    */   
/* 610:    */   private static void updateSizesFromChildren(DimensionInfo info, boolean min, int[] widths)
/* 611:    */   {
/* 612:691 */     for (int i = info.getComponentCount() - 1; i >= 0; i--)
/* 613:    */     {
/* 614:692 */       Component child = info.getComponent(i);
/* 615:693 */       GridConstraints c = info.getConstraints(i);
/* 616:694 */       if ((c.isUseParentLayout()) && ((child instanceof Container)))
/* 617:    */       {
/* 618:695 */         Container container = (Container)child;
/* 619:696 */         if ((container.getLayout() instanceof GridLayoutManager))
/* 620:    */         {
/* 621:697 */           updateSizesFromChild(info, min, widths, container, i);
/* 622:    */         }
/* 623:699 */         else if ((container.getComponentCount() == 1) && ((container.getComponent(0) instanceof Container)))
/* 624:    */         {
/* 625:702 */           Container childContainer = (Container)container.getComponent(0);
/* 626:703 */           if ((childContainer.getLayout() instanceof GridLayoutManager)) {
/* 627:704 */             updateSizesFromChild(info, min, widths, childContainer, i);
/* 628:    */           }
/* 629:    */         }
/* 630:    */       }
/* 631:    */     }
/* 632:    */   }
/* 633:    */   
/* 634:    */   private static void updateSizesFromChild(DimensionInfo info, boolean min, int[] widths, Container container, int childIndex)
/* 635:    */   {
/* 636:716 */     GridLayoutManager childLayout = (GridLayoutManager)container.getLayout();
/* 637:717 */     if (info.getSpan(childIndex) == info.getChildLayoutCellCount(childLayout))
/* 638:    */     {
/* 639:718 */       childLayout.validateInfos(container);
/* 640:719 */       DimensionInfo childInfo = (info instanceof HorizontalInfo) ? childLayout.myHorizontalInfo : childLayout.myVerticalInfo;
/* 641:    */       
/* 642:    */ 
/* 643:722 */       int[] sizes = childLayout.getMinOrPrefSizes(childInfo, min);
/* 644:723 */       int cell = info.getCell(childIndex);
/* 645:724 */       for (int j = 0; j < sizes.length; j++) {
/* 646:725 */         widths[(cell + j)] = Math.max(widths[(cell + j)], sizes[j]);
/* 647:    */       }
/* 648:    */     }
/* 649:    */   }
/* 650:    */   
/* 651:    */   private static int getMin2(DimensionInfo info, int componentIndex)
/* 652:    */   {
/* 653:    */     int s;
/* 654:    */     int s;
/* 655:733 */     if ((info.getSizePolicy(componentIndex) & 0x1) != 0) {
/* 656:734 */       s = info.getMinimumWidth(componentIndex);
/* 657:    */     } else {
/* 658:739 */       s = Math.max(info.getMinimumWidth(componentIndex), info.getPreferredWidth(componentIndex));
/* 659:    */     }
/* 660:741 */     return s;
/* 661:    */   }
/* 662:    */   
/* 663:    */   private void new_doIt(int[] widths, int cell, int span, int minWidth, DimensionInfo info, boolean checkPrefs)
/* 664:    */   {
/* 665:748 */     int toDistribute = minWidth;
/* 666:750 */     for (int i = cell; i < cell + span; i++) {
/* 667:751 */       toDistribute -= widths[i];
/* 668:    */     }
/* 669:753 */     if (toDistribute <= 0) {
/* 670:754 */       return;
/* 671:    */     }
/* 672:757 */     boolean[] allowedCells = new boolean[info.getCellCount()];
/* 673:758 */     for (int i = cell; i < cell + span; i++) {
/* 674:759 */       allowedCells[i] = true;
/* 675:    */     }
/* 676:762 */     boolean[] higherPriorityCells = new boolean[info.getCellCount()];
/* 677:763 */     getCellsWithHigherPriorities(info, allowedCells, higherPriorityCells, checkPrefs, widths);
/* 678:    */     
/* 679:765 */     distribute(higherPriorityCells, info, toDistribute, widths);
/* 680:    */   }
/* 681:    */   
/* 682:    */   private static void distribute(boolean[] higherPriorityCells, DimensionInfo info, int toDistribute, int[] widths)
/* 683:    */   {
/* 684:769 */     int stretches = 0;
/* 685:770 */     for (int i = 0; i < info.getCellCount(); i++) {
/* 686:771 */       if (higherPriorityCells[i] != 0) {
/* 687:772 */         stretches += info.getStretch(i);
/* 688:    */       }
/* 689:    */     }
/* 690:777 */     int toDistributeFrozen = toDistribute;
/* 691:778 */     for (int i = 0; i < info.getCellCount(); i++) {
/* 692:779 */       if (higherPriorityCells[i] != 0)
/* 693:    */       {
/* 694:783 */         int addon = toDistributeFrozen * info.getStretch(i) / stretches;
/* 695:784 */         widths[i] += addon;
/* 696:    */         
/* 697:786 */         toDistribute -= addon;
/* 698:    */       }
/* 699:    */     }
/* 700:790 */     if (toDistribute != 0) {
/* 701:791 */       for (int i = 0; i < info.getCellCount(); i++) {
/* 702:792 */         if (higherPriorityCells[i] != 0)
/* 703:    */         {
/* 704:796 */           widths[i] += 1;
/* 705:797 */           toDistribute--;
/* 706:799 */           if (toDistribute == 0) {
/* 707:    */             break;
/* 708:    */           }
/* 709:    */         }
/* 710:    */       }
/* 711:    */     }
/* 712:805 */     if (toDistribute != 0) {
/* 713:806 */       throw new IllegalStateException("toDistribute = " + toDistribute);
/* 714:    */     }
/* 715:    */   }
/* 716:    */   
/* 717:    */   private void getCellsWithHigherPriorities(DimensionInfo info, boolean[] allowedCells, boolean[] higherPriorityCells, boolean checkPrefs, int[] widths)
/* 718:    */   {
/* 719:817 */     Arrays.fill(higherPriorityCells, false);
/* 720:    */     
/* 721:819 */     int foundCells = 0;
/* 722:821 */     if (checkPrefs)
/* 723:    */     {
/* 724:823 */       int[] prefs = getMinOrPrefSizes(info, false);
/* 725:824 */       for (int cell = 0; cell < allowedCells.length; cell++) {
/* 726:825 */         if (allowedCells[cell] != 0) {
/* 727:828 */           if ((!isCellEmpty(info, cell)) && (prefs[cell] > widths[cell]))
/* 728:    */           {
/* 729:829 */             higherPriorityCells[cell] = true;
/* 730:830 */             foundCells++;
/* 731:    */           }
/* 732:    */         }
/* 733:    */       }
/* 734:834 */       if (foundCells > 0) {
/* 735:835 */         return;
/* 736:    */       }
/* 737:    */     }
/* 738:840 */     for (int cell = 0; cell < allowedCells.length; cell++) {
/* 739:841 */       if (allowedCells[cell] != 0) {
/* 740:844 */         if ((info.getCellSizePolicy(cell) & 0x4) != 0)
/* 741:    */         {
/* 742:845 */           higherPriorityCells[cell] = true;
/* 743:846 */           foundCells++;
/* 744:    */         }
/* 745:    */       }
/* 746:    */     }
/* 747:850 */     if (foundCells > 0) {
/* 748:851 */       return;
/* 749:    */     }
/* 750:855 */     for (int cell = 0; cell < allowedCells.length; cell++) {
/* 751:856 */       if (allowedCells[cell] != 0) {
/* 752:859 */         if ((info.getCellSizePolicy(cell) & 0x2) != 0)
/* 753:    */         {
/* 754:860 */           higherPriorityCells[cell] = true;
/* 755:861 */           foundCells++;
/* 756:    */         }
/* 757:    */       }
/* 758:    */     }
/* 759:865 */     if (foundCells > 0) {
/* 760:866 */       return;
/* 761:    */     }
/* 762:870 */     for (int cell = 0; cell < allowedCells.length; cell++) {
/* 763:871 */       if (allowedCells[cell] != 0) {
/* 764:874 */         if (!isCellEmpty(info, cell))
/* 765:    */         {
/* 766:875 */           higherPriorityCells[cell] = true;
/* 767:876 */           foundCells++;
/* 768:    */         }
/* 769:    */       }
/* 770:    */     }
/* 771:880 */     if (foundCells > 0) {
/* 772:881 */       return;
/* 773:    */     }
/* 774:885 */     for (int cell = 0; cell < allowedCells.length; cell++) {
/* 775:886 */       if (allowedCells[cell] != 0) {
/* 776:889 */         higherPriorityCells[cell] = true;
/* 777:    */       }
/* 778:    */     }
/* 779:    */   }
/* 780:    */   
/* 781:    */   public boolean isSameSizeHorizontally()
/* 782:    */   {
/* 783:894 */     return this.mySameSizeHorizontally;
/* 784:    */   }
/* 785:    */   
/* 786:    */   public boolean isSameSizeVertically()
/* 787:    */   {
/* 788:898 */     return this.mySameSizeVertically;
/* 789:    */   }
/* 790:    */   
/* 791:    */   public void setSameSizeHorizontally(boolean sameSizeHorizontally)
/* 792:    */   {
/* 793:902 */     this.mySameSizeHorizontally = sameSizeHorizontally;
/* 794:    */   }
/* 795:    */   
/* 796:    */   public void setSameSizeVertically(boolean sameSizeVertically)
/* 797:    */   {
/* 798:906 */     this.mySameSizeVertically = sameSizeVertically;
/* 799:    */   }
/* 800:    */   
/* 801:    */   public int[] getHorizontalGridLines()
/* 802:    */   {
/* 803:910 */     int[] result = new int[this.myYs.length + 1];
/* 804:911 */     result[0] = this.myYs[0];
/* 805:912 */     for (int i = 0; i < this.myYs.length - 1; i++) {
/* 806:913 */       result[(i + 1)] = ((this.myYs[i] + this.myHeights[i] + this.myYs[(i + 1)]) / 2);
/* 807:    */     }
/* 808:915 */     result[this.myYs.length] = (this.myYs[(this.myYs.length - 1)] + this.myHeights[(this.myYs.length - 1)]);
/* 809:916 */     return result;
/* 810:    */   }
/* 811:    */   
/* 812:    */   public int[] getVerticalGridLines()
/* 813:    */   {
/* 814:920 */     int[] result = new int[this.myXs.length + 1];
/* 815:921 */     result[0] = this.myXs[0];
/* 816:922 */     for (int i = 0; i < this.myXs.length - 1; i++) {
/* 817:923 */       result[(i + 1)] = ((this.myXs[i] + this.myWidths[i] + this.myXs[(i + 1)]) / 2);
/* 818:    */     }
/* 819:925 */     result[this.myXs.length] = (this.myXs[(this.myXs.length - 1)] + this.myWidths[(this.myXs.length - 1)]);
/* 820:926 */     return result;
/* 821:    */   }
/* 822:    */   
/* 823:    */   public int getCellCount(boolean isRow)
/* 824:    */   {
/* 825:930 */     return isRow ? getRowCount() : getColumnCount();
/* 826:    */   }
/* 827:    */   
/* 828:    */   public int getCellSizePolicy(boolean isRow, int cellIndex)
/* 829:    */   {
/* 830:934 */     DimensionInfo info = isRow ? this.myVerticalInfo : this.myHorizontalInfo;
/* 831:935 */     if (info == null) {
/* 832:937 */       return 0;
/* 833:    */     }
/* 834:939 */     return info.getCellSizePolicy(cellIndex);
/* 835:    */   }
/* 836:    */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.GridLayoutManager
 * JD-Core Version:    0.7.0.1
 */