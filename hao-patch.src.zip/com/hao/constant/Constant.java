/*  1:   */ package com.hao.constant;
/*  2:   */ 
/*  3:   */ import java.nio.charset.Charset;
/*  4:   */ 
/*  5:   */ public class Constant
/*  6:   */ {
/*  7:   */   public static final String PATCH_ROOT = ".patchmaster";
/*  8:   */   public static final String PATCH_PATH = "patchPath.txt";
/*  9:   */   public static final String COPY_PATH = "copyPath.txt";
/* 10:17 */   public static final Charset CHARSET = Charset.forName("UTF-8");
/* 11:   */   public static final String LINE_COMMENT = "#TODO";
/* 12:   */   public static final String DELETE_COMMENT = "#Delete";
/* 13:   */   public static final String EDIT_COMMENT = "#Add or update";
/* 14:   */   public static final String TEST_COMMENT = "#Test case";
/* 15:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.hao.constant.Constant
 * JD-Core Version:    0.7.0.1
 */