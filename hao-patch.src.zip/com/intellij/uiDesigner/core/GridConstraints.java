/*   1:    */ package com.intellij.uiDesigner.core;
/*   2:    */ 
/*   3:    */ import java.awt.Dimension;
/*   4:    */ 
/*   5:    */ public final class GridConstraints
/*   6:    */   implements Cloneable
/*   7:    */ {
/*   8: 25 */   public static final GridConstraints[] EMPTY_ARRAY = new GridConstraints[0];
/*   9:    */   public static final int FILL_NONE = 0;
/*  10:    */   public static final int FILL_HORIZONTAL = 1;
/*  11:    */   public static final int FILL_VERTICAL = 2;
/*  12:    */   public static final int FILL_BOTH = 3;
/*  13:    */   public static final int ANCHOR_CENTER = 0;
/*  14:    */   public static final int ANCHOR_NORTH = 1;
/*  15:    */   public static final int ANCHOR_SOUTH = 2;
/*  16:    */   public static final int ANCHOR_EAST = 4;
/*  17:    */   public static final int ANCHOR_WEST = 8;
/*  18:    */   public static final int ANCHOR_NORTHEAST = 5;
/*  19:    */   public static final int ANCHOR_SOUTHEAST = 6;
/*  20:    */   public static final int ANCHOR_SOUTHWEST = 10;
/*  21:    */   public static final int ANCHOR_NORTHWEST = 9;
/*  22:    */   public static final int SIZEPOLICY_FIXED = 0;
/*  23:    */   public static final int SIZEPOLICY_CAN_SHRINK = 1;
/*  24:    */   public static final int SIZEPOLICY_CAN_GROW = 2;
/*  25:    */   public static final int SIZEPOLICY_WANT_GROW = 4;
/*  26:    */   public static final int ALIGN_LEFT = 0;
/*  27:    */   public static final int ALIGN_CENTER = 1;
/*  28:    */   public static final int ALIGN_RIGHT = 2;
/*  29:    */   public static final int ALIGN_FILL = 3;
/*  30:    */   private int myRow;
/*  31:    */   private int myColumn;
/*  32:    */   private int myRowSpan;
/*  33:    */   private int myColSpan;
/*  34:    */   private int myVSizePolicy;
/*  35:    */   private int myHSizePolicy;
/*  36:    */   private int myFill;
/*  37:    */   private int myAnchor;
/*  38:    */   public final Dimension myMinimumSize;
/*  39:    */   public final Dimension myPreferredSize;
/*  40:    */   public final Dimension myMaximumSize;
/*  41:    */   private int myIndent;
/*  42:    */   private boolean myUseParentLayout;
/*  43:    */   
/*  44:    */   public GridConstraints()
/*  45:    */   {
/*  46:135 */     this.myRowSpan = 1;
/*  47:136 */     this.myColSpan = 1;
/*  48:137 */     this.myVSizePolicy = 3;
/*  49:138 */     this.myHSizePolicy = 3;
/*  50:139 */     this.myFill = 0;
/*  51:140 */     this.myAnchor = 0;
/*  52:141 */     this.myMinimumSize = new Dimension(-1, -1);
/*  53:142 */     this.myPreferredSize = new Dimension(-1, -1);
/*  54:143 */     this.myMaximumSize = new Dimension(-1, -1);
/*  55:144 */     this.myIndent = 0;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public GridConstraints(int row, int column, int rowSpan, int colSpan, int anchor, int fill, int HSizePolicy, int VSizePolicy, Dimension minimumSize, Dimension preferredSize, Dimension maximumSize)
/*  59:    */   {
/*  60:159 */     this.myRow = row;
/*  61:160 */     this.myColumn = column;
/*  62:161 */     this.myRowSpan = rowSpan;
/*  63:162 */     this.myColSpan = colSpan;
/*  64:163 */     this.myAnchor = anchor;
/*  65:164 */     this.myFill = fill;
/*  66:165 */     this.myHSizePolicy = HSizePolicy;
/*  67:166 */     this.myVSizePolicy = VSizePolicy;
/*  68:167 */     this.myMinimumSize = (minimumSize != null ? new Dimension(minimumSize) : new Dimension(-1, -1));
/*  69:168 */     this.myPreferredSize = (preferredSize != null ? new Dimension(preferredSize) : new Dimension(-1, -1));
/*  70:169 */     this.myMaximumSize = (maximumSize != null ? new Dimension(maximumSize) : new Dimension(-1, -1));
/*  71:170 */     this.myIndent = 0;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public GridConstraints(int row, int column, int rowSpan, int colSpan, int anchor, int fill, int HSizePolicy, int VSizePolicy, Dimension minimumSize, Dimension preferredSize, Dimension maximumSize, int indent)
/*  75:    */   {
/*  76:186 */     this(row, column, rowSpan, colSpan, anchor, fill, HSizePolicy, VSizePolicy, minimumSize, preferredSize, maximumSize);
/*  77:187 */     this.myIndent = indent;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public GridConstraints(int row, int column, int rowSpan, int colSpan, int anchor, int fill, int HSizePolicy, int VSizePolicy, Dimension minimumSize, Dimension preferredSize, Dimension maximumSize, int indent, boolean useParentLayout)
/*  81:    */   {
/*  82:204 */     this(row, column, rowSpan, colSpan, anchor, fill, HSizePolicy, VSizePolicy, minimumSize, preferredSize, maximumSize, indent);
/*  83:205 */     this.myUseParentLayout = useParentLayout;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Object clone()
/*  87:    */   {
/*  88:212 */     return new GridConstraints(this.myRow, this.myColumn, this.myRowSpan, this.myColSpan, this.myAnchor, this.myFill, this.myHSizePolicy, this.myVSizePolicy, new Dimension(this.myMinimumSize), new Dimension(this.myPreferredSize), new Dimension(this.myMaximumSize), this.myIndent, this.myUseParentLayout);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public int getColumn()
/*  92:    */   {
/*  93:218 */     return this.myColumn;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void setColumn(int column)
/*  97:    */   {
/*  98:222 */     if (column < 0) {
/*  99:223 */       throw new IllegalArgumentException("wrong column: " + column);
/* 100:    */     }
/* 101:225 */     this.myColumn = column;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public int getRow()
/* 105:    */   {
/* 106:229 */     return this.myRow;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void setRow(int row)
/* 110:    */   {
/* 111:233 */     if (row < 0) {
/* 112:234 */       throw new IllegalArgumentException("wrong row: " + row);
/* 113:    */     }
/* 114:236 */     this.myRow = row;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public int getRowSpan()
/* 118:    */   {
/* 119:240 */     return this.myRowSpan;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setRowSpan(int rowSpan)
/* 123:    */   {
/* 124:244 */     if (rowSpan <= 0) {
/* 125:245 */       throw new IllegalArgumentException("wrong rowSpan: " + rowSpan);
/* 126:    */     }
/* 127:247 */     this.myRowSpan = rowSpan;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public int getColSpan()
/* 131:    */   {
/* 132:251 */     return this.myColSpan;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setColSpan(int colSpan)
/* 136:    */   {
/* 137:255 */     if (colSpan <= 0) {
/* 138:256 */       throw new IllegalArgumentException("wrong colSpan: " + colSpan);
/* 139:    */     }
/* 140:258 */     this.myColSpan = colSpan;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public int getHSizePolicy()
/* 144:    */   {
/* 145:262 */     return this.myHSizePolicy;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void setHSizePolicy(int sizePolicy)
/* 149:    */   {
/* 150:266 */     if ((sizePolicy < 0) || (sizePolicy > 7)) {
/* 151:267 */       throw new IllegalArgumentException("invalid sizePolicy: " + sizePolicy);
/* 152:    */     }
/* 153:269 */     this.myHSizePolicy = sizePolicy;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public int getVSizePolicy()
/* 157:    */   {
/* 158:273 */     return this.myVSizePolicy;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void setVSizePolicy(int sizePolicy)
/* 162:    */   {
/* 163:277 */     if ((sizePolicy < 0) || (sizePolicy > 7)) {
/* 164:278 */       throw new IllegalArgumentException("invalid sizePolicy: " + sizePolicy);
/* 165:    */     }
/* 166:280 */     this.myVSizePolicy = sizePolicy;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public int getAnchor()
/* 170:    */   {
/* 171:284 */     return this.myAnchor;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void setAnchor(int anchor)
/* 175:    */   {
/* 176:288 */     if ((anchor < 0) || (anchor > 15)) {
/* 177:289 */       throw new IllegalArgumentException("invalid anchor: " + anchor);
/* 178:    */     }
/* 179:291 */     this.myAnchor = anchor;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public int getFill()
/* 183:    */   {
/* 184:295 */     return this.myFill;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void setFill(int fill)
/* 188:    */   {
/* 189:299 */     if ((fill != 0) && (fill != 1) && (fill != 2) && (fill != 3)) {
/* 190:305 */       throw new IllegalArgumentException("invalid fill: " + fill);
/* 191:    */     }
/* 192:307 */     this.myFill = fill;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public int getIndent()
/* 196:    */   {
/* 197:311 */     return this.myIndent;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void setIndent(int indent)
/* 201:    */   {
/* 202:315 */     this.myIndent = indent;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public boolean isUseParentLayout()
/* 206:    */   {
/* 207:319 */     return this.myUseParentLayout;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void setUseParentLayout(boolean useParentLayout)
/* 211:    */   {
/* 212:323 */     this.myUseParentLayout = useParentLayout;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public GridConstraints store()
/* 216:    */   {
/* 217:327 */     GridConstraints copy = new GridConstraints();
/* 218:    */     
/* 219:329 */     copy.setRow(this.myRow);
/* 220:330 */     copy.setColumn(this.myColumn);
/* 221:331 */     copy.setColSpan(this.myColSpan);
/* 222:332 */     copy.setRowSpan(this.myRowSpan);
/* 223:333 */     copy.setVSizePolicy(this.myVSizePolicy);
/* 224:334 */     copy.setHSizePolicy(this.myHSizePolicy);
/* 225:335 */     copy.setFill(this.myFill);
/* 226:336 */     copy.setAnchor(this.myAnchor);
/* 227:337 */     copy.setIndent(this.myIndent);
/* 228:338 */     copy.setUseParentLayout(this.myUseParentLayout);
/* 229:    */     
/* 230:340 */     copy.myMinimumSize.setSize(this.myMinimumSize);
/* 231:341 */     copy.myPreferredSize.setSize(this.myPreferredSize);
/* 232:342 */     copy.myMaximumSize.setSize(this.myMaximumSize);
/* 233:    */     
/* 234:344 */     return copy;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public void restore(GridConstraints constraints)
/* 238:    */   {
/* 239:348 */     this.myRow = constraints.myRow;
/* 240:349 */     this.myColumn = constraints.myColumn;
/* 241:350 */     this.myRowSpan = constraints.myRowSpan;
/* 242:351 */     this.myColSpan = constraints.myColSpan;
/* 243:352 */     this.myHSizePolicy = constraints.myHSizePolicy;
/* 244:353 */     this.myVSizePolicy = constraints.myVSizePolicy;
/* 245:354 */     this.myFill = constraints.myFill;
/* 246:355 */     this.myAnchor = constraints.myAnchor;
/* 247:356 */     this.myIndent = constraints.myIndent;
/* 248:357 */     this.myUseParentLayout = constraints.myUseParentLayout;
/* 249:    */     
/* 250:    */ 
/* 251:360 */     this.myMinimumSize.setSize(constraints.myMinimumSize);
/* 252:361 */     this.myPreferredSize.setSize(constraints.myPreferredSize);
/* 253:362 */     this.myMaximumSize.setSize(constraints.myMaximumSize);
/* 254:    */   }
/* 255:    */   
/* 256:    */   public boolean equals(Object o)
/* 257:    */   {
/* 258:366 */     if (this == o) {
/* 259:366 */       return true;
/* 260:    */     }
/* 261:367 */     if (!(o instanceof GridConstraints)) {
/* 262:367 */       return false;
/* 263:    */     }
/* 264:369 */     GridConstraints gridConstraints = (GridConstraints)o;
/* 265:371 */     if (this.myAnchor != gridConstraints.myAnchor) {
/* 266:371 */       return false;
/* 267:    */     }
/* 268:372 */     if (this.myColSpan != gridConstraints.myColSpan) {
/* 269:372 */       return false;
/* 270:    */     }
/* 271:373 */     if (this.myColumn != gridConstraints.myColumn) {
/* 272:373 */       return false;
/* 273:    */     }
/* 274:374 */     if (this.myFill != gridConstraints.myFill) {
/* 275:374 */       return false;
/* 276:    */     }
/* 277:375 */     if (this.myHSizePolicy != gridConstraints.myHSizePolicy) {
/* 278:375 */       return false;
/* 279:    */     }
/* 280:376 */     if (this.myRow != gridConstraints.myRow) {
/* 281:376 */       return false;
/* 282:    */     }
/* 283:377 */     if (this.myRowSpan != gridConstraints.myRowSpan) {
/* 284:377 */       return false;
/* 285:    */     }
/* 286:378 */     if (this.myVSizePolicy != gridConstraints.myVSizePolicy) {
/* 287:378 */       return false;
/* 288:    */     }
/* 289:379 */     if (this.myMaximumSize != null ? !this.myMaximumSize.equals(gridConstraints.myMaximumSize) : gridConstraints.myMaximumSize != null) {
/* 290:379 */       return false;
/* 291:    */     }
/* 292:380 */     if (this.myMinimumSize != null ? !this.myMinimumSize.equals(gridConstraints.myMinimumSize) : gridConstraints.myMinimumSize != null) {
/* 293:380 */       return false;
/* 294:    */     }
/* 295:381 */     if (this.myPreferredSize != null ? !this.myPreferredSize.equals(gridConstraints.myPreferredSize) : gridConstraints.myPreferredSize != null) {
/* 296:381 */       return false;
/* 297:    */     }
/* 298:382 */     if (this.myIndent != gridConstraints.myIndent) {
/* 299:382 */       return false;
/* 300:    */     }
/* 301:383 */     if (this.myUseParentLayout != gridConstraints.myUseParentLayout) {
/* 302:383 */       return false;
/* 303:    */     }
/* 304:385 */     return true;
/* 305:    */   }
/* 306:    */   
/* 307:    */   public int hashCode()
/* 308:    */   {
/* 309:390 */     int result = this.myRow;
/* 310:391 */     result = 29 * result + this.myColumn;
/* 311:392 */     result = 29 * result + this.myRowSpan;
/* 312:393 */     result = 29 * result + this.myColSpan;
/* 313:394 */     result = 29 * result + this.myVSizePolicy;
/* 314:395 */     result = 29 * result + this.myHSizePolicy;
/* 315:396 */     result = 29 * result + this.myFill;
/* 316:397 */     result = 29 * result + this.myAnchor;
/* 317:398 */     result = 29 * result + (this.myMinimumSize != null ? this.myMinimumSize.hashCode() : 0);
/* 318:399 */     result = 29 * result + (this.myPreferredSize != null ? this.myPreferredSize.hashCode() : 0);
/* 319:400 */     result = 29 * result + (this.myMaximumSize != null ? this.myMaximumSize.hashCode() : 0);
/* 320:401 */     result = 29 * result + this.myIndent;
/* 321:402 */     result = 29 * result + (this.myUseParentLayout ? 1 : 0);
/* 322:403 */     return result;
/* 323:    */   }
/* 324:    */   
/* 325:    */   public int getCell(boolean isRow)
/* 326:    */   {
/* 327:407 */     return isRow ? getRow() : getColumn();
/* 328:    */   }
/* 329:    */   
/* 330:    */   public void setCell(boolean isRow, int value)
/* 331:    */   {
/* 332:411 */     if (isRow) {
/* 333:412 */       setRow(value);
/* 334:    */     } else {
/* 335:415 */       setColumn(value);
/* 336:    */     }
/* 337:    */   }
/* 338:    */   
/* 339:    */   public int getSpan(boolean isRow)
/* 340:    */   {
/* 341:420 */     return isRow ? getRowSpan() : getColSpan();
/* 342:    */   }
/* 343:    */   
/* 344:    */   public void setSpan(boolean isRow, int value)
/* 345:    */   {
/* 346:424 */     if (isRow) {
/* 347:425 */       setRowSpan(value);
/* 348:    */     } else {
/* 349:428 */       setColSpan(value);
/* 350:    */     }
/* 351:    */   }
/* 352:    */   
/* 353:    */   public boolean contains(boolean isRow, int cell)
/* 354:    */   {
/* 355:433 */     if (isRow) {
/* 356:434 */       return (cell >= this.myRow) && (cell < this.myRow + this.myRowSpan);
/* 357:    */     }
/* 358:436 */     return (cell >= this.myColumn) && (cell < this.myColumn + this.myColSpan);
/* 359:    */   }
/* 360:    */   
/* 361:    */   public String toString()
/* 362:    */   {
/* 363:441 */     return "GridConstraints (row=" + this.myRow + ", col=" + this.myColumn + ", rowspan=" + this.myRowSpan + ", colspan=" + this.myColSpan + ")";
/* 364:    */   }
/* 365:    */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.GridConstraints
 * JD-Core Version:    0.7.0.1
 */