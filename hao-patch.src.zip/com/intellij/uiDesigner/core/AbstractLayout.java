/*   1:    */ package com.intellij.uiDesigner.core;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Insets;
/*   7:    */ import java.awt.LayoutManager2;
/*   8:    */ 
/*   9:    */ public abstract class AbstractLayout
/*  10:    */   implements LayoutManager2
/*  11:    */ {
/*  12:    */   public static final int DEFAULT_HGAP = 10;
/*  13:    */   public static final int DEFAULT_VGAP = 5;
/*  14:    */   protected Component[] myComponents;
/*  15:    */   protected GridConstraints[] myConstraints;
/*  16:    */   protected Insets myMargin;
/*  17:    */   private int myHGap;
/*  18:    */   private int myVGap;
/*  19: 49 */   private static final Component[] COMPONENT_EMPTY_ARRAY = new Component[0];
/*  20:    */   
/*  21:    */   public AbstractLayout()
/*  22:    */   {
/*  23: 52 */     this.myComponents = COMPONENT_EMPTY_ARRAY;
/*  24: 53 */     this.myConstraints = GridConstraints.EMPTY_ARRAY;
/*  25: 54 */     this.myMargin = new Insets(0, 0, 0, 0);
/*  26: 55 */     this.myHGap = -1;
/*  27: 56 */     this.myVGap = -1;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public final Insets getMargin()
/*  31:    */   {
/*  32: 60 */     return (Insets)this.myMargin.clone();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public final int getHGap()
/*  36:    */   {
/*  37: 68 */     return this.myHGap;
/*  38:    */   }
/*  39:    */   
/*  40:    */   protected static int getHGapImpl(Container container)
/*  41:    */   {
/*  42: 77 */     if (container == null) {
/*  43: 78 */       throw new IllegalArgumentException("container cannot be null");
/*  44:    */     }
/*  45: 80 */     while (container != null)
/*  46:    */     {
/*  47: 81 */       if ((container.getLayout() instanceof AbstractLayout))
/*  48:    */       {
/*  49: 82 */         AbstractLayout layout = (AbstractLayout)container.getLayout();
/*  50: 83 */         if (layout.getHGap() != -1) {
/*  51: 84 */           return layout.getHGap();
/*  52:    */         }
/*  53:    */       }
/*  54: 87 */       container = container.getParent();
/*  55:    */     }
/*  56: 89 */     return 10;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public final void setHGap(int hGap)
/*  60:    */   {
/*  61:100 */     if (hGap < -1) {
/*  62:101 */       throw new IllegalArgumentException("wrong hGap: " + hGap);
/*  63:    */     }
/*  64:103 */     this.myHGap = hGap;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public final int getVGap()
/*  68:    */   {
/*  69:111 */     return this.myVGap;
/*  70:    */   }
/*  71:    */   
/*  72:    */   protected static int getVGapImpl(Container container)
/*  73:    */   {
/*  74:120 */     if (container == null) {
/*  75:121 */       throw new IllegalArgumentException("container cannot be null");
/*  76:    */     }
/*  77:123 */     while (container != null)
/*  78:    */     {
/*  79:124 */       if ((container.getLayout() instanceof AbstractLayout))
/*  80:    */       {
/*  81:125 */         AbstractLayout layout = (AbstractLayout)container.getLayout();
/*  82:126 */         if (layout.getVGap() != -1) {
/*  83:127 */           return layout.getVGap();
/*  84:    */         }
/*  85:    */       }
/*  86:130 */       container = container.getParent();
/*  87:    */     }
/*  88:132 */     return 5;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public final void setVGap(int vGap)
/*  92:    */   {
/*  93:145 */     if (vGap < -1) {
/*  94:146 */       throw new IllegalArgumentException("wrong vGap: " + vGap);
/*  95:    */     }
/*  96:148 */     this.myVGap = vGap;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public final void setMargin(Insets margin)
/* 100:    */   {
/* 101:152 */     if (margin == null) {
/* 102:153 */       throw new IllegalArgumentException("margin cannot be null");
/* 103:    */     }
/* 104:155 */     this.myMargin = ((Insets)margin.clone());
/* 105:    */   }
/* 106:    */   
/* 107:    */   final int getComponentCount()
/* 108:    */   {
/* 109:159 */     return this.myComponents.length;
/* 110:    */   }
/* 111:    */   
/* 112:    */   final Component getComponent(int index)
/* 113:    */   {
/* 114:163 */     return this.myComponents[index];
/* 115:    */   }
/* 116:    */   
/* 117:    */   final GridConstraints getConstraints(int index)
/* 118:    */   {
/* 119:167 */     return this.myConstraints[index];
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void addLayoutComponent(Component comp, Object constraints)
/* 123:    */   {
/* 124:171 */     if (!(constraints instanceof GridConstraints)) {
/* 125:172 */       throw new IllegalArgumentException("constraints: " + constraints);
/* 126:    */     }
/* 127:175 */     Component[] newComponents = new Component[this.myComponents.length + 1];
/* 128:176 */     System.arraycopy(this.myComponents, 0, newComponents, 0, this.myComponents.length);
/* 129:177 */     newComponents[this.myComponents.length] = comp;
/* 130:178 */     this.myComponents = newComponents;
/* 131:    */     
/* 132:180 */     GridConstraints[] newConstraints = new GridConstraints[this.myConstraints.length + 1];
/* 133:181 */     System.arraycopy(this.myConstraints, 0, newConstraints, 0, this.myConstraints.length);
/* 134:182 */     newConstraints[this.myConstraints.length] = ((GridConstraints)((GridConstraints)constraints).clone());
/* 135:183 */     this.myConstraints = newConstraints;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public final void addLayoutComponent(String name, Component comp)
/* 139:    */   {
/* 140:187 */     throw new UnsupportedOperationException();
/* 141:    */   }
/* 142:    */   
/* 143:    */   public final void removeLayoutComponent(Component comp)
/* 144:    */   {
/* 145:191 */     int i = getComponentIndex(comp);
/* 146:192 */     if (i == -1) {
/* 147:193 */       throw new IllegalArgumentException("component was not added: " + comp);
/* 148:    */     }
/* 149:196 */     if (this.myComponents.length == 1)
/* 150:    */     {
/* 151:197 */       this.myComponents = COMPONENT_EMPTY_ARRAY;
/* 152:    */     }
/* 153:    */     else
/* 154:    */     {
/* 155:200 */       Component[] newComponents = new Component[this.myComponents.length - 1];
/* 156:201 */       System.arraycopy(this.myComponents, 0, newComponents, 0, i);
/* 157:202 */       System.arraycopy(this.myComponents, i + 1, newComponents, i, this.myComponents.length - i - 1);
/* 158:203 */       this.myComponents = newComponents;
/* 159:    */     }
/* 160:206 */     if (this.myConstraints.length == 1)
/* 161:    */     {
/* 162:207 */       this.myConstraints = GridConstraints.EMPTY_ARRAY;
/* 163:    */     }
/* 164:    */     else
/* 165:    */     {
/* 166:210 */       GridConstraints[] newConstraints = new GridConstraints[this.myConstraints.length - 1];
/* 167:211 */       System.arraycopy(this.myConstraints, 0, newConstraints, 0, i);
/* 168:212 */       System.arraycopy(this.myConstraints, i + 1, newConstraints, i, this.myConstraints.length - i - 1);
/* 169:213 */       this.myConstraints = newConstraints;
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   public GridConstraints getConstraintsForComponent(Component comp)
/* 174:    */   {
/* 175:218 */     int i = getComponentIndex(comp);
/* 176:219 */     if (i == -1) {
/* 177:220 */       throw new IllegalArgumentException("component was not added: " + comp);
/* 178:    */     }
/* 179:223 */     return this.myConstraints[i];
/* 180:    */   }
/* 181:    */   
/* 182:    */   private int getComponentIndex(Component comp)
/* 183:    */   {
/* 184:227 */     for (int i = 0; i < this.myComponents.length; i++)
/* 185:    */     {
/* 186:228 */       Component component = this.myComponents[i];
/* 187:229 */       if (component == comp) {
/* 188:230 */         return i;
/* 189:    */       }
/* 190:    */     }
/* 191:233 */     return -1;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public final float getLayoutAlignmentX(Container container)
/* 195:    */   {
/* 196:237 */     return 0.5F;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public final float getLayoutAlignmentY(Container container)
/* 200:    */   {
/* 201:241 */     return 0.5F;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public abstract Dimension maximumLayoutSize(Container paramContainer);
/* 205:    */   
/* 206:    */   public abstract void invalidateLayout(Container paramContainer);
/* 207:    */   
/* 208:    */   public abstract Dimension preferredLayoutSize(Container paramContainer);
/* 209:    */   
/* 210:    */   public abstract Dimension minimumLayoutSize(Container paramContainer);
/* 211:    */   
/* 212:    */   public abstract void layoutContainer(Container paramContainer);
/* 213:    */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.AbstractLayout
 * JD-Core Version:    0.7.0.1
 */