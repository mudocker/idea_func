/*  1:   */ package com.hao.util;
/*  2:   */ 
/*  3:   */ import com.intellij.openapi.ui.Messages;
/*  4:   */ 
/*  5:   */ public class MessageUtils
/*  6:   */ {
/*  7:   */   private static final String DEFAULT_TITLE = "Do Patch";
/*  8:   */   
/*  9:   */   public static void alert(String title, String message)
/* 10:   */   {
/* 11:10 */     Messages.showDialog(message, title, new String[] { "OK" }, -1, null);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static void alert(String message)
/* 15:   */   {
/* 16:14 */     alert("Do Patch", message);
/* 17:   */   }
/* 18:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.hao.util.MessageUtils
 * JD-Core Version:    0.7.0.1
 */