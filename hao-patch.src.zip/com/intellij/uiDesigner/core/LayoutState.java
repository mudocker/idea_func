/*  1:   */ package com.intellij.uiDesigner.core;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ 
/*  7:   */ public final class LayoutState
/*  8:   */ {
/*  9:   */   private final Component[] myComponents;
/* 10:   */   private final GridConstraints[] myConstraints;
/* 11:   */   private final int myColumnCount;
/* 12:   */   private final int myRowCount;
/* 13:   */   final Dimension[] myPreferredSizes;
/* 14:   */   final Dimension[] myMinimumSizes;
/* 15:   */   
/* 16:   */   public LayoutState(GridLayoutManager layout, boolean ignoreInvisibleComponents)
/* 17:   */   {
/* 18:34 */     ArrayList componentsList = new ArrayList(layout.getComponentCount());
/* 19:35 */     ArrayList constraintsList = new ArrayList(layout.getComponentCount());
/* 20:36 */     for (int i = 0; i < layout.getComponentCount(); i++)
/* 21:   */     {
/* 22:37 */       Component component = layout.getComponent(i);
/* 23:38 */       if ((!ignoreInvisibleComponents) || (component.isVisible()))
/* 24:   */       {
/* 25:39 */         componentsList.add(component);
/* 26:40 */         GridConstraints constraints = layout.getConstraints(i);
/* 27:41 */         constraintsList.add(constraints);
/* 28:   */       }
/* 29:   */     }
/* 30:45 */     this.myComponents = ((Component[])componentsList.toArray(new Component[0]));
/* 31:46 */     this.myConstraints = ((GridConstraints[])constraintsList.toArray(GridConstraints.EMPTY_ARRAY));
/* 32:   */     
/* 33:48 */     this.myMinimumSizes = new Dimension[this.myComponents.length];
/* 34:49 */     this.myPreferredSizes = new Dimension[this.myComponents.length];
/* 35:   */     
/* 36:51 */     this.myColumnCount = layout.getColumnCount();
/* 37:52 */     this.myRowCount = layout.getRowCount();
/* 38:   */   }
/* 39:   */   
/* 40:   */   public int getComponentCount()
/* 41:   */   {
/* 42:56 */     return this.myComponents.length;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Component getComponent(int index)
/* 46:   */   {
/* 47:60 */     return this.myComponents[index];
/* 48:   */   }
/* 49:   */   
/* 50:   */   public GridConstraints getConstraints(int index)
/* 51:   */   {
/* 52:64 */     return this.myConstraints[index];
/* 53:   */   }
/* 54:   */   
/* 55:   */   public int getColumnCount()
/* 56:   */   {
/* 57:68 */     return this.myColumnCount;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public int getRowCount()
/* 61:   */   {
/* 62:72 */     return this.myRowCount;
/* 63:   */   }
/* 64:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.LayoutState
 * JD-Core Version:    0.7.0.1
 */