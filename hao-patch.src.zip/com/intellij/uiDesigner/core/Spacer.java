/*  1:   */ package com.intellij.uiDesigner.core;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ 
/*  6:   */ public class Spacer
/*  7:   */   extends JComponent
/*  8:   */ {
/*  9:   */   public Dimension getMinimumSize()
/* 10:   */   {
/* 11:23 */     return new Dimension(0, 0);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public final Dimension getPreferredSize()
/* 15:   */   {
/* 16:27 */     return getMinimumSize();
/* 17:   */   }
/* 18:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.Spacer
 * JD-Core Version:    0.7.0.1
 */