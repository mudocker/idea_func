/*   1:    */ package com.intellij.uiDesigner.core;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ 
/*   7:    */ public final class Util
/*   8:    */ {
/*   9: 22 */   private static final Dimension MAX_SIZE = new Dimension(2147483647, 2147483647);
/*  10:    */   public static final int DEFAULT_INDENT = 10;
/*  11:    */   
/*  12:    */   public static Dimension getMinimumSize(Component component, GridConstraints constraints, boolean addIndent)
/*  13:    */   {
/*  14:    */     try
/*  15:    */     {
/*  16: 27 */       Dimension size = getSize(constraints.myMinimumSize, component.getMinimumSize());
/*  17: 28 */       if (addIndent) {
/*  18: 29 */         size.width += 10 * constraints.getIndent();
/*  19:    */       }
/*  20: 31 */       return size;
/*  21:    */     }
/*  22:    */     catch (NullPointerException npe) {}
/*  23: 33 */     return new Dimension(0, 0);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static Dimension getMaximumSize(Component component, GridConstraints constraints, boolean addIndent)
/*  27:    */   {
/*  28:    */     try
/*  29:    */     {
/*  30: 42 */       Dimension size = getSize(constraints.myMaximumSize, MAX_SIZE);
/*  31: 43 */       if ((addIndent) && (size.width < MAX_SIZE.width)) {
/*  32: 44 */         size.width += 10 * constraints.getIndent();
/*  33:    */       }
/*  34: 46 */       return size;
/*  35:    */     }
/*  36:    */     catch (NullPointerException e) {}
/*  37: 49 */     return new Dimension(0, 0);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static Dimension getPreferredSize(Component component, GridConstraints constraints, boolean addIndent)
/*  41:    */   {
/*  42:    */     try
/*  43:    */     {
/*  44: 55 */       Dimension size = getSize(constraints.myPreferredSize, component.getPreferredSize());
/*  45: 56 */       if (addIndent) {
/*  46: 57 */         size.width += 10 * constraints.getIndent();
/*  47:    */       }
/*  48: 59 */       return size;
/*  49:    */     }
/*  50:    */     catch (NullPointerException e) {}
/*  51: 62 */     return new Dimension(0, 0);
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static Dimension getSize(Dimension overridenSize, Dimension ownSize)
/*  55:    */   {
/*  56: 67 */     int overridenWidth = overridenSize.width >= 0 ? overridenSize.width : ownSize.width;
/*  57: 68 */     int overridenHeight = overridenSize.height >= 0 ? overridenSize.height : ownSize.height;
/*  58: 69 */     return new Dimension(overridenWidth, overridenHeight);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static void adjustSize(Component component, GridConstraints constraints, Dimension size)
/*  62:    */   {
/*  63: 73 */     Dimension minimumSize = getMinimumSize(component, constraints, false);
/*  64: 74 */     Dimension maximumSize = getMaximumSize(component, constraints, false);
/*  65:    */     
/*  66: 76 */     size.width = Math.max(size.width, minimumSize.width);
/*  67: 77 */     size.height = Math.max(size.height, minimumSize.height);
/*  68:    */     
/*  69: 79 */     size.width = Math.min(size.width, maximumSize.width);
/*  70: 80 */     size.height = Math.min(size.height, maximumSize.height);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static int eliminate(int[] cellIndices, int[] spans, ArrayList elimitated)
/*  74:    */   {
/*  75: 89 */     int size = cellIndices.length;
/*  76: 90 */     if (size != spans.length) {
/*  77: 91 */       throw new IllegalArgumentException("size mismatch: " + size + ", " + spans.length);
/*  78:    */     }
/*  79: 93 */     if ((elimitated != null) && (elimitated.size() != 0)) {
/*  80: 94 */       throw new IllegalArgumentException("eliminated must be empty");
/*  81:    */     }
/*  82: 97 */     int cellCount = 0;
/*  83: 98 */     for (int i = 0; i < size; i++) {
/*  84: 99 */       cellCount = Math.max(cellCount, cellIndices[i] + spans[i]);
/*  85:    */     }
/*  86:102 */     for (int cell = cellCount - 1; cell >= 0; cell--)
/*  87:    */     {
/*  88:105 */       boolean starts = false;
/*  89:106 */       boolean ends = false;
/*  90:108 */       for (int i = 0; i < size; i++)
/*  91:    */       {
/*  92:109 */         if (cellIndices[i] == cell) {
/*  93:110 */           starts = true;
/*  94:    */         }
/*  95:112 */         if (cellIndices[i] + spans[i] - 1 == cell) {
/*  96:113 */           ends = true;
/*  97:    */         }
/*  98:    */       }
/*  99:117 */       if ((!starts) || (!ends))
/* 100:    */       {
/* 101:121 */         if (elimitated != null) {
/* 102:122 */           elimitated.add(new Integer(cell));
/* 103:    */         }
/* 104:126 */         for (int i = 0; i < size; i++)
/* 105:    */         {
/* 106:127 */           boolean decreaseSpan = (cellIndices[i] <= cell) && (cell < cellIndices[i] + spans[i]);
/* 107:128 */           boolean decreaseIndex = cellIndices[i] > cell;
/* 108:130 */           if (decreaseSpan) {
/* 109:131 */             spans[i] -= 1;
/* 110:    */           }
/* 111:134 */           if (decreaseIndex) {
/* 112:135 */             cellIndices[i] -= 1;
/* 113:    */           }
/* 114:    */         }
/* 115:139 */         cellCount--;
/* 116:    */       }
/* 117:    */     }
/* 118:142 */     return cellCount;
/* 119:    */   }
/* 120:    */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.Util
 * JD-Core Version:    0.7.0.1
 */