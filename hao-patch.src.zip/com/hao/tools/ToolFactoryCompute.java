/*  1:   */ package com.hao.tools;
/*  2:   */ 
/*  3:   */ import com.hao.util.VirtualFileUtils;
/*  4:   */ import com.intellij.openapi.diagnostic.Logger;
/*  5:   */ import com.intellij.openapi.fileEditor.FileEditorManager;
/*  6:   */ import com.intellij.openapi.fileEditor.FileEditorManagerEvent;
/*  7:   */ import com.intellij.openapi.fileEditor.FileEditorManagerListener;
/*  8:   */ import com.intellij.openapi.project.Project;
/*  9:   */ import com.intellij.openapi.util.text.StringUtil;
/* 10:   */ import com.intellij.openapi.vfs.VirtualFile;
/* 11:   */ import com.intellij.openapi.wm.ToolWindow;
/* 12:   */ import com.intellij.openapi.wm.ToolWindowFactory;
/* 13:   */ import com.intellij.ui.JBColor;
/* 14:   */ import com.intellij.ui.content.Content;
/* 15:   */ import com.intellij.ui.content.ContentFactory;
/* 16:   */ import com.intellij.ui.content.ContentFactory.SERVICE;
/* 17:   */ import com.intellij.ui.content.ContentManager;
/* 18:   */ import com.intellij.util.messages.MessageBus;
/* 19:   */ import com.intellij.util.messages.MessageBusConnection;
/* 20:   */ import java.util.List;
/* 21:   */ import javax.swing.BorderFactory;
/* 22:   */ import javax.swing.JPanel;
/* 23:   */ import javax.swing.JScrollPane;
/* 24:   */ import javax.swing.JTree;
/* 25:   */ import javax.swing.JViewport;
/* 26:   */ import javax.swing.tree.DefaultMutableTreeNode;
/* 27:   */ import javax.swing.tree.DefaultTreeModel;
/* 28:   */ import javax.swing.tree.MutableTreeNode;
/* 29:   */ import org.jetbrains.annotations.NotNull;
/* 30:   */ 
/* 31:   */ public class ToolFactoryCompute
/* 32:   */   implements ToolWindowFactory
/* 33:   */ {
/* 34:   */   private static final Logger logger;
/* 35:   */   public static final String TOOL_WINDOW_ID = "Jstructure";
/* 36:   */   private JPanel myPanel;
/* 37:   */   private JScrollPane myScrollPane;
/* 38:   */   private JTree javaTree;
/* 39:   */   
/* 40:   */   public ToolFactoryCompute()
/* 41:   */   {
/* 42:29 */     $$$setupUI$$$();
/* 43:   */   }
/* 44:   */   
/* 45:   */   static
/* 46:   */   {
/* 47:31 */     ToolFactoryCompute.logger = Logger.getInstance(ToolFactoryCompute.class);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void createToolWindowContent(@NotNull Project project, @NotNull final ToolWindow toolWindow)
/* 51:   */   {
/* 52:41 */     if (project == null) {
/* 53:41 */       $$$reportNull$$$0(0);
/* 54:   */     }
/* 55:41 */     if (toolWindow == null) {
/* 56:41 */       $$$reportNull$$$0(1);
/* 57:   */     }
/* 58:41 */     Content content = ContentFactory.SERVICE.getInstance().createContent(this.myPanel, "", false);
/* 59:42 */     content.setCloseable(false);
/* 60:43 */     toolWindow.getContentManager().addContent(content);
/* 61:   */     
/* 62:   */ 
/* 63:46 */     MessageBus messageBus = project.getMessageBus();
/* 64:47 */     messageBus.connect().subscribe(FileEditorManagerListener.FILE_EDITOR_MANAGER, new FileEditorManagerListener()
/* 65:   */     {
/* 66:   */       public void selectionChanged(@NotNull FileEditorManagerEvent event)
/* 67:   */       {
/* 68:50 */         if (event == null) {
/* 69:50 */           $$$reportNull$$$0(0);
/* 70:   */         }
/* 71:50 */         if ((null == event.getNewFile()) || (!toolWindow.isVisible())) {
/* 72:51 */           return;
/* 73:   */         }
/* 74:53 */         ToolFactoryCompute.this.javaView(event.getManager(), event.getNewFile());
/* 75:   */       }
/* 76:   */     });
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void init(ToolWindow toolWindow)
/* 80:   */   {
/* 81:69 */     this.javaTree.setOpaque(false);
/* 82:70 */     this.myPanel.setOpaque(false);
/* 83:71 */     this.myScrollPane.setOpaque(false);
/* 84:72 */     this.myScrollPane.getViewport().setOpaque(false);
/* 85:   */     
/* 86:   */ 
/* 87:75 */     this.javaTree.setBorder(BorderFactory.createLineBorder(JBColor.BLACK, 0));
/* 88:76 */     this.myScrollPane.setBorder(BorderFactory.createLineBorder(JBColor.BLACK, 0));
/* 89:77 */     this.myPanel.setBorder(BorderFactory.createLineBorder(JBColor.BLACK, 0));
/* 90:   */   }
/* 91:   */   
/* 92:   */   private void javaView(@NotNull FileEditorManager manager, @NotNull VirtualFile file)
/* 93:   */   {
/* 94:81 */     if (manager == null) {
/* 95:81 */       $$$reportNull$$$0(2);
/* 96:   */     }
/* 97:81 */     if (file == null) {
/* 98:81 */       $$$reportNull$$$0(3);
/* 99:   */     }
/* :0:81 */     if (!StringUtil.endsWith(file.getName(), ".java")) {
/* :1:82 */       return;
/* :2:   */     }
/* :3:85 */     String fileName = file.getName();
/* :4:86 */     fileName = StringUtil.substringBefore(fileName, ".");
/* :5:   */     
/* :6:88 */     DefaultMutableTreeNode root = new DefaultMutableTreeNode(fileName);
/* :7:89 */     List<String> lines = VirtualFileUtils.readLines(file);
/* :8:90 */     for (String line : lines) {
/* :9:91 */       if ((line.contains("(")) && (line.contains(")")))
/* ;0:   */       {
/* ;1:92 */         MutableTreeNode lv1 = new DefaultMutableTreeNode(line);
/* ;2:93 */         root.add(lv1);
/* ;3:   */       }
/* ;4:   */     }
/* ;5:97 */     DefaultTreeModel tree = new DefaultTreeModel(root);
/* ;6:98 */     this.javaTree.setModel(tree);
/* ;7:99 */     this.myPanel.setVisible(true);
/* ;8:   */   }
/* ;9:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.hao.tools.ToolFactoryCompute
 * JD-Core Version:    0.7.0.1
 */