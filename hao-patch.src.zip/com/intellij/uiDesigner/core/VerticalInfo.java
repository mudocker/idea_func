/*  1:   */ package com.intellij.uiDesigner.core;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ 
/*  5:   */ final class VerticalInfo
/*  6:   */   extends DimensionInfo
/*  7:   */ {
/*  8:   */   public VerticalInfo(LayoutState layoutState, int gap)
/*  9:   */   {
/* 10:20 */     super(layoutState, gap);
/* 11:   */   }
/* 12:   */   
/* 13:   */   protected int getOriginalCell(GridConstraints constraints)
/* 14:   */   {
/* 15:24 */     return constraints.getRow();
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected int getOriginalSpan(GridConstraints constraints)
/* 19:   */   {
/* 20:28 */     return constraints.getRowSpan();
/* 21:   */   }
/* 22:   */   
/* 23:   */   int getSizePolicy(int componentIndex)
/* 24:   */   {
/* 25:32 */     return this.myLayoutState.getConstraints(componentIndex).getVSizePolicy();
/* 26:   */   }
/* 27:   */   
/* 28:   */   int getChildLayoutCellCount(GridLayoutManager childLayout)
/* 29:   */   {
/* 30:36 */     return childLayout.getRowCount();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public int getMinimumWidth(int componentIndex)
/* 34:   */   {
/* 35:40 */     return getMinimumSize(componentIndex).height;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public DimensionInfo getDimensionInfo(GridLayoutManager grid)
/* 39:   */   {
/* 40:44 */     return grid.myVerticalInfo;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public int getCellCount()
/* 44:   */   {
/* 45:48 */     return this.myLayoutState.getRowCount();
/* 46:   */   }
/* 47:   */   
/* 48:   */   public int getPreferredWidth(int componentIndex)
/* 49:   */   {
/* 50:52 */     return getPreferredSize(componentIndex).height;
/* 51:   */   }
/* 52:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.VerticalInfo
 * JD-Core Version:    0.7.0.1
 */