/*  1:   */ package com.intellij.uiDesigner.core;
/*  2:   */ 
/*  3:   */ import java.lang.reflect.Method;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ 
/*  6:   */ public final class SupportCode
/*  7:   */ {
/*  8:   */   public static TextWithMnemonic parseText(String textWithMnemonic)
/*  9:   */   {
/* 10:30 */     if (textWithMnemonic == null) {
/* 11:31 */       throw new IllegalArgumentException("textWithMnemonic cannot be null");
/* 12:   */     }
/* 13:34 */     int index = -1;
/* 14:35 */     StringBuffer plainText = new StringBuffer();
/* 15:36 */     for (int i = 0; i < textWithMnemonic.length(); i++)
/* 16:   */     {
/* 17:37 */       char ch = textWithMnemonic.charAt(i);
/* 18:38 */       if (ch == '&')
/* 19:   */       {
/* 20:39 */         i++;
/* 21:40 */         if (i >= textWithMnemonic.length()) {
/* 22:   */           break;
/* 23:   */         }
/* 24:43 */         ch = textWithMnemonic.charAt(i);
/* 25:44 */         if (ch != '&') {
/* 26:45 */           index = plainText.length();
/* 27:   */         }
/* 28:   */       }
/* 29:48 */       plainText.append(ch);
/* 30:   */     }
/* 31:51 */     return new TextWithMnemonic(plainText.toString(), index, null);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static final class TextWithMnemonic
/* 35:   */   {
/* 36:   */     public final String myText;
/* 37:   */     public final int myMnemonicIndex;
/* 38:   */     
/* 39:   */     TextWithMnemonic(String x0, int x1, SupportCode.1 x2)
/* 40:   */     {
/* 41:54 */       this(x0, x1);
/* 42:   */     }
/* 43:   */     
/* 44:   */     private TextWithMnemonic(String text, int index)
/* 45:   */     {
/* 46:65 */       if (text == null) {
/* 47:66 */         throw new IllegalArgumentException("text cannot be null");
/* 48:   */       }
/* 49:68 */       if ((index != -1) && ((index < 0) || (index >= text.length()))) {
/* 50:69 */         throw new IllegalArgumentException("wrong index: " + index + "; text = '" + text + "'");
/* 51:   */       }
/* 52:71 */       this.myText = text;
/* 53:72 */       this.myMnemonicIndex = index;
/* 54:   */     }
/* 55:   */     
/* 56:   */     public char getMnemonicChar()
/* 57:   */     {
/* 58:76 */       if (this.myMnemonicIndex == -1) {
/* 59:77 */         throw new IllegalStateException("text doesn't contain mnemonic");
/* 60:   */       }
/* 61:79 */       return Character.toUpperCase(this.myText.charAt(this.myMnemonicIndex));
/* 62:   */     }
/* 63:   */   }
/* 64:   */   
/* 65:   */   public static void setDisplayedMnemonicIndex(JComponent component, int index)
/* 66:   */   {
/* 67:   */     try
/* 68:   */     {
/* 69:89 */       Method method = component.getClass().getMethod("setDisplayedMnemonicIndex", new Class[] { Integer.TYPE });
/* 70:90 */       method.setAccessible(true);
/* 71:91 */       method.invoke(component, new Object[] { new Integer(index) });
/* 72:   */     }
/* 73:   */     catch (Exception localException) {}
/* 74:   */   }
/* 75:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.SupportCode
 * JD-Core Version:    0.7.0.1
 */