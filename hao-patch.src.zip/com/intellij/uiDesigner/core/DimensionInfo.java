/*   1:    */ package com.intellij.uiDesigner.core;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ 
/*   8:    */ public abstract class DimensionInfo
/*   9:    */ {
/*  10:    */   private final int[] myCell;
/*  11:    */   private final int[] mySpan;
/*  12:    */   protected final LayoutState myLayoutState;
/*  13:    */   private final int[] myStretches;
/*  14:    */   private final int[] mySpansAfterElimination;
/*  15:    */   private final int[] myCellSizePolicies;
/*  16:    */   private final int myGap;
/*  17:    */   
/*  18:    */   public DimensionInfo(LayoutState layoutState, int gap)
/*  19:    */   {
/*  20: 35 */     if (layoutState == null) {
/*  21: 36 */       throw new IllegalArgumentException("layoutState cannot be null");
/*  22:    */     }
/*  23: 38 */     if (gap < 0) {
/*  24: 39 */       throw new IllegalArgumentException("invalid gap: " + gap);
/*  25:    */     }
/*  26: 41 */     this.myLayoutState = layoutState;
/*  27: 42 */     this.myGap = gap;
/*  28:    */     
/*  29: 44 */     this.myCell = new int[layoutState.getComponentCount()];
/*  30: 45 */     this.mySpan = new int[layoutState.getComponentCount()];
/*  31: 47 */     for (int i = 0; i < layoutState.getComponentCount(); i++)
/*  32:    */     {
/*  33: 48 */       GridConstraints c = layoutState.getConstraints(i);
/*  34: 49 */       this.myCell[i] = getOriginalCell(c);
/*  35: 50 */       this.mySpan[i] = getOriginalSpan(c);
/*  36:    */     }
/*  37: 53 */     this.myStretches = new int[getCellCount()];
/*  38: 54 */     for (int i = 0; i < this.myStretches.length; i++) {
/*  39: 55 */       this.myStretches[i] = 1;
/*  40:    */     }
/*  41: 59 */     ArrayList elimitated = new ArrayList();
/*  42: 60 */     this.mySpansAfterElimination = ((int[])this.mySpan.clone());
/*  43: 61 */     Util.eliminate((int[])this.myCell.clone(), this.mySpansAfterElimination, elimitated);
/*  44:    */     
/*  45: 63 */     this.myCellSizePolicies = new int[getCellCount()];
/*  46: 64 */     for (int i = 0; i < this.myCellSizePolicies.length; i++) {
/*  47: 65 */       this.myCellSizePolicies[i] = getCellSizePolicyImpl(i, elimitated);
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public final int getComponentCount()
/*  52:    */   {
/*  53: 70 */     return this.myLayoutState.getComponentCount();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public final Component getComponent(int componentIndex)
/*  57:    */   {
/*  58: 74 */     return this.myLayoutState.getComponent(componentIndex);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public final GridConstraints getConstraints(int componentIndex)
/*  62:    */   {
/*  63: 78 */     return this.myLayoutState.getConstraints(componentIndex);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public abstract int getCellCount();
/*  67:    */   
/*  68:    */   public abstract int getPreferredWidth(int paramInt);
/*  69:    */   
/*  70:    */   public abstract int getMinimumWidth(int paramInt);
/*  71:    */   
/*  72:    */   public abstract DimensionInfo getDimensionInfo(GridLayoutManager paramGridLayoutManager);
/*  73:    */   
/*  74:    */   public final int getCell(int componentIndex)
/*  75:    */   {
/*  76: 88 */     return this.myCell[componentIndex];
/*  77:    */   }
/*  78:    */   
/*  79:    */   public final int getSpan(int componentIndex)
/*  80:    */   {
/*  81: 92 */     return this.mySpan[componentIndex];
/*  82:    */   }
/*  83:    */   
/*  84:    */   public final int getStretch(int cellIndex)
/*  85:    */   {
/*  86: 96 */     return this.myStretches[cellIndex];
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected abstract int getOriginalCell(GridConstraints paramGridConstraints);
/*  90:    */   
/*  91:    */   protected abstract int getOriginalSpan(GridConstraints paramGridConstraints);
/*  92:    */   
/*  93:    */   abstract int getSizePolicy(int paramInt);
/*  94:    */   
/*  95:    */   abstract int getChildLayoutCellCount(GridLayoutManager paramGridLayoutManager);
/*  96:    */   
/*  97:    */   public final int getGap()
/*  98:    */   {
/*  99:107 */     return this.myGap;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean componentBelongsCell(int componentIndex, int cellIndex)
/* 103:    */   {
/* 104:111 */     int componentStartCell = getCell(componentIndex);
/* 105:112 */     int span = getSpan(componentIndex);
/* 106:113 */     return (componentStartCell <= cellIndex) && (cellIndex < componentStartCell + span);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public final int getCellSizePolicy(int cellIndex)
/* 110:    */   {
/* 111:117 */     return this.myCellSizePolicies[cellIndex];
/* 112:    */   }
/* 113:    */   
/* 114:    */   private int getCellSizePolicyImpl(int cellIndex, ArrayList eliminatedCells)
/* 115:    */   {
/* 116:121 */     int policyFromChild = getCellSizePolicyFromInheriting(cellIndex);
/* 117:122 */     if (policyFromChild != -1) {
/* 118:123 */       return policyFromChild;
/* 119:    */     }
/* 120:125 */     for (int i = eliminatedCells.size() - 1; i >= 0; i--) {
/* 121:126 */       if (cellIndex == ((Integer)eliminatedCells.get(i)).intValue()) {
/* 122:127 */         return 1;
/* 123:    */       }
/* 124:    */     }
/* 125:131 */     return calcCellSizePolicy(cellIndex);
/* 126:    */   }
/* 127:    */   
/* 128:    */   private int calcCellSizePolicy(int cellIndex)
/* 129:    */   {
/* 130:135 */     boolean canShrink = true;
/* 131:136 */     boolean canGrow = false;
/* 132:137 */     boolean wantGrow = false;
/* 133:    */     
/* 134:139 */     boolean weakCanGrow = true;
/* 135:140 */     boolean weakWantGrow = true;
/* 136:    */     
/* 137:142 */     int countOfBelongingComponents = 0;
/* 138:144 */     for (int i = 0; i < getComponentCount(); i++) {
/* 139:145 */       if (componentBelongsCell(i, cellIndex))
/* 140:    */       {
/* 141:149 */         countOfBelongingComponents++;
/* 142:    */         
/* 143:151 */         int p = getSizePolicy(i);
/* 144:    */         
/* 145:153 */         boolean thisCanShrink = (p & 0x1) != 0;
/* 146:154 */         boolean thisCanGrow = (p & 0x2) != 0;
/* 147:155 */         boolean thisWantGrow = (p & 0x4) != 0;
/* 148:157 */         if ((getCell(i) == cellIndex) && (this.mySpansAfterElimination[i] == 1))
/* 149:    */         {
/* 150:158 */           canShrink &= thisCanShrink;
/* 151:159 */           canGrow |= thisCanGrow;
/* 152:160 */           wantGrow |= thisWantGrow;
/* 153:    */         }
/* 154:163 */         if (!thisCanGrow) {
/* 155:164 */           weakCanGrow = false;
/* 156:    */         }
/* 157:166 */         if (!thisWantGrow) {
/* 158:167 */           weakWantGrow = false;
/* 159:    */         }
/* 160:    */       }
/* 161:    */     }
/* 162:171 */     return (canShrink ? 1 : 0) | ((canGrow) || ((countOfBelongingComponents > 0) && (weakCanGrow)) ? 2 : 0) | ((wantGrow) || ((countOfBelongingComponents > 0) && (weakWantGrow)) ? 4 : 0);
/* 163:    */   }
/* 164:    */   
/* 165:    */   private int getCellSizePolicyFromInheriting(int cellIndex)
/* 166:    */   {
/* 167:178 */     int nonInheritingComponentsInCell = 0;
/* 168:179 */     int policyFromInheriting = -1;
/* 169:180 */     for (int i = getComponentCount() - 1; i >= 0; i--) {
/* 170:181 */       if (componentBelongsCell(i, cellIndex))
/* 171:    */       {
/* 172:184 */         Component child = getComponent(i);
/* 173:185 */         GridConstraints c = getConstraints(i);
/* 174:186 */         Container container = findAlignedChild(child, c);
/* 175:187 */         if (container != null)
/* 176:    */         {
/* 177:188 */           GridLayoutManager grid = (GridLayoutManager)container.getLayout();
/* 178:189 */           grid.validateInfos(container);
/* 179:190 */           DimensionInfo info = getDimensionInfo(grid);
/* 180:191 */           int policy = info.calcCellSizePolicy(cellIndex - getOriginalCell(c));
/* 181:192 */           if (policyFromInheriting == -1) {
/* 182:193 */             policyFromInheriting = policy;
/* 183:    */           } else {
/* 184:196 */             policyFromInheriting |= policy;
/* 185:    */           }
/* 186:    */         }
/* 187:199 */         else if ((getOriginalCell(c) == cellIndex) && (getOriginalSpan(c) == 1) && (!(child instanceof Spacer)))
/* 188:    */         {
/* 189:200 */           nonInheritingComponentsInCell++;
/* 190:    */         }
/* 191:    */       }
/* 192:    */     }
/* 193:203 */     if (nonInheritingComponentsInCell > 0) {
/* 194:204 */       return -1;
/* 195:    */     }
/* 196:206 */     return policyFromInheriting;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public static Container findAlignedChild(Component child, GridConstraints c)
/* 200:    */   {
/* 201:210 */     if ((c.isUseParentLayout()) && ((child instanceof Container)))
/* 202:    */     {
/* 203:211 */       Container container = (Container)child;
/* 204:212 */       if ((container.getLayout() instanceof GridLayoutManager)) {
/* 205:213 */         return container;
/* 206:    */       }
/* 207:215 */       if ((container.getComponentCount() == 1) && ((container.getComponent(0) instanceof Container)))
/* 208:    */       {
/* 209:218 */         Container childContainer = (Container)container.getComponent(0);
/* 210:219 */         if ((childContainer.getLayout() instanceof GridLayoutManager)) {
/* 211:220 */           return childContainer;
/* 212:    */         }
/* 213:    */       }
/* 214:    */     }
/* 215:224 */     return null;
/* 216:    */   }
/* 217:    */   
/* 218:    */   protected final Dimension getPreferredSize(int componentIndex)
/* 219:    */   {
/* 220:228 */     Dimension size = this.myLayoutState.myPreferredSizes[componentIndex];
/* 221:229 */     if (size == null)
/* 222:    */     {
/* 223:230 */       size = Util.getPreferredSize(this.myLayoutState.getComponent(componentIndex), this.myLayoutState.getConstraints(componentIndex), true);
/* 224:231 */       this.myLayoutState.myPreferredSizes[componentIndex] = size;
/* 225:    */     }
/* 226:233 */     return size;
/* 227:    */   }
/* 228:    */   
/* 229:    */   protected final Dimension getMinimumSize(int componentIndex)
/* 230:    */   {
/* 231:237 */     Dimension size = this.myLayoutState.myMinimumSizes[componentIndex];
/* 232:238 */     if (size == null)
/* 233:    */     {
/* 234:239 */       size = Util.getMinimumSize(this.myLayoutState.getComponent(componentIndex), this.myLayoutState.getConstraints(componentIndex), true);
/* 235:240 */       this.myLayoutState.myMinimumSizes[componentIndex] = size;
/* 236:    */     }
/* 237:242 */     return size;
/* 238:    */   }
/* 239:    */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.intellij.uiDesigner.core.DimensionInfo
 * JD-Core Version:    0.7.0.1
 */