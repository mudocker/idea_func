/*  1:   */ package com.hao.util;
/*  2:   */ 
/*  3:   */ import com.google.common.io.Files;
/*  4:   */ import com.hao.constant.Constant;
/*  5:   */ import com.intellij.openapi.diagnostic.Logger;
/*  6:   */ import com.intellij.openapi.util.text.StringUtil;
/*  7:   */ import com.intellij.openapi.vfs.VirtualFile;
/*  8:   */ import java.io.BufferedWriter;
/*  9:   */ import java.io.File;
/* 10:   */ import java.io.IOException;
/* 11:   */ import java.util.List;
/* 12:   */ 
/* 13:   */ public class VirtualFileUtils
/* 14:   */ {
/* 15:16 */   private static final Logger logger = Logger.getInstance(VirtualFileUtils.class);
/* 16:   */   
/* 17:   */   public static void appendLine(VirtualFile vfile, List<String> lines)
/* 18:   */   {
/* 19:   */     try
/* 20:   */     {
/* 21:20 */       File file = new File(vfile.getPath());
/* 22:21 */       List<String> list = Files.readLines(file, Constant.CHARSET);
/* 23:22 */       BufferedWriter bufferedWriter = Files.newWriter(file, Constant.CHARSET);
/* 24:23 */       if (!list.isEmpty())
/* 25:   */       {
/* 26:24 */         writerLine(list, bufferedWriter);
/* 27:25 */         bufferedWriter.newLine();
/* 28:   */       }
/* 29:27 */       if (!lines.isEmpty()) {
/* 30:28 */         writerLine(lines, bufferedWriter);
/* 31:   */       }
/* 32:30 */       bufferedWriter.close();
/* 33:   */     }
/* 34:   */     catch (Exception e)
/* 35:   */     {
/* 36:32 */       logger.error("appendLine faild", e);
/* 37:   */     }
/* 38:34 */     refresh(vfile);
/* 39:   */   }
/* 40:   */   
/* 41:   */   private static void writerLine(List<String> list, BufferedWriter bufferedWriter)
/* 42:   */     throws IOException
/* 43:   */   {
/* 44:38 */     for (String path : list) {
/* 45:39 */       if (StringUtil.isEmpty(path))
/* 46:   */       {
/* 47:40 */         bufferedWriter.newLine();
/* 48:   */       }
/* 49:   */       else
/* 50:   */       {
/* 51:43 */         bufferedWriter.write(path);
/* 52:44 */         bufferedWriter.newLine();
/* 53:   */       }
/* 54:   */     }
/* 55:   */   }
/* 56:   */   
/* 57:   */   public static void refresh(VirtualFile vfile)
/* 58:   */   {
/* 59:49 */     vfile.refresh(true, false);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public static List<String> readLines(VirtualFile vfile)
/* 63:   */   {
/* 64:53 */     if ((null == vfile) || (!vfile.exists()) || (vfile.isDirectory())) {
/* 65:54 */       return null;
/* 66:   */     }
/* 67:   */     try
/* 68:   */     {
/* 69:56 */       File file = new File(vfile.getPath());
/* 70:57 */       return Files.readLines(file, Constant.CHARSET);
/* 71:   */     }
/* 72:   */     catch (Exception e)
/* 73:   */     {
/* 74:59 */       logger.error("readLines faild", e);
/* 75:   */     }
/* 76:61 */     return null;
/* 77:   */   }
/* 78:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     com.hao.util.VirtualFileUtils
 * JD-Core Version:    0.7.0.1
 */