/*  1:   */ package icons;
/*  2:   */ 
/*  3:   */ import com.intellij.openapi.util.IconLoader;
/*  4:   */ import javax.swing.Icon;
/*  5:   */ 
/*  6:   */ public class HaoIcons
/*  7:   */ {
/*  8:   */   private static Icon load(String path)
/*  9:   */   {
/* 10:10 */     return IconLoader.getIcon(path, HaoIcons.class);
/* 11:   */   }
/* 12:   */   
/* 13:13 */   public static final Icon Jstructure = load("/icons/Jstructure.png");
/* 14:   */ }


/* Location:           E:\sd\hao-patch.jar
 * Qualified Name:     icons.HaoIcons
 * JD-Core Version:    0.7.0.1
 */